----------------------------------------------------------------
-- PASS 05: CONTROL FLOW OBFUSCATION
-- Injects garbage variables, dead tables, opaque if-end blocks,
-- and pointless arithmetic after random safe lines
----------------------------------------------------------------
return function(source, env)
    local rng = env.prng.rng
    local genName = env.naming.genName
    local utils = env.utils

    local lines = utils.splitLines(source)
    if #lines == 0 then return source end

    local function opaque()
        return utils.opaque(rng)
    end

    local safe = {}
    for i = 1, #lines do
        if utils.isSafeLine(lines[i]) then safe[#safe + 1] = i end
    end

    local after = {}
    if #safe > 2 then
        for i = #safe, 2, -1 do local j = rng(1, i); safe[i], safe[j] = safe[j], safe[i] end
        local cnt = math.min(rng(4, 12), #safe)
        for ii = 1, cnt do after[safe[ii]] = true end
    end

    local result = {}
    for i = 1, #lines do
        result[#result + 1] = lines[i]
        if after[i] then
            local act = rng(1, 4)
            if act == 1 then
                result[#result + 1] = "local " .. genName() .. "=" .. rng(100, 99999)
            elseif act == 2 then
                local t = {}
                for _ = 1, rng(2, 6) do t[#t + 1] = rng(1, 99999) end
                result[#result + 1] = "local " .. genName() .. "={" .. table.concat(t, ",") .. "}"
            elseif act == 3 then
                result[#result + 1] = "if " .. opaque() .. " then end"
            else
                local vn = genName(); local a = rng(10, 999); local b = rng(10, 999)
                result[#result + 1] = "local " .. vn .. "=" .. a .. "+" .. b .. "-" .. b
            end
        end
    end
    return utils.joinLines(result)
end
