----------------------------------------------------------------
-- PASS 12: ANTI-FORMAT
-- Destroys code structure and readability by randomizing
-- indentation, adding blank lines, and inserting semicolons
----------------------------------------------------------------
return function(source, env)
    local rng = env.prng.rng
    local utils = env.utils

    local lines = utils.splitLines(source)
    if #lines == 0 then return source end

    local result = {}
    for i = 1, #lines do
        local line = lines[i]
        local trimmed = line:match("^%s*(.-)%s*$")
        if #trimmed == 0 then
            result[#result + 1] = ""
        else
            local choice = rng(1, 4)
            if choice == 1 then
                result[#result + 1] = trimmed
            elseif choice == 2 then
                local indent = string.rep(" ", rng(0, 8))
                result[#result + 1] = indent .. trimmed
            elseif choice == 3 then
                local semi = rng(1, 3) == 1 and ";" or ""
                result[#result + 1] = trimmed .. semi
            else
                result[#result + 1] = trimmed
                result[#result + 1] = ""
            end
        end
    end
    return utils.joinLines(result)
end
