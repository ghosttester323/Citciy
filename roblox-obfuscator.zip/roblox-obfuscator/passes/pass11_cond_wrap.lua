----------------------------------------------------------------
-- PASS 11: CONDITIONAL WRAPPING
-- Wraps individual statements inside if (always-true) then ... end
-- blocks to add another layer of indirection
----------------------------------------------------------------
return function(source, env)
    local rng = env.prng.rng
    local pick = env.prng.pick
    local utils = env.utils

    local lines = utils.splitLines(source)
    if #lines == 0 then return source end

    local function opaque()
        local a, b = rng(100, 9999), rng(100, 9999)
        return pick({
            "(not false)",
            "(" .. a .. "+" .. b .. "-" .. a .. "==" .. b .. ")",
            '(type(' .. rng(10, 999) .. ')=="number")',
            "((" .. a .. "+" .. b .. ")^0==1)",
            "(not not true)",
        })
    end

    local function isWrapSafe(line)
        if not utils.isSafeLine(line) then return false end
        local t = line:match("^%s*(.-)%s*$")
        if t:match("^local[%s]") or t:match("^local$") then return false end
        if t:match("^local function") or t:match("^function ") then return false end
        if t:match("^return") then return false end
        return true
    end

    local safe = {}
    for i = 1, #lines do
        if isWrapSafe(lines[i]) then safe[#safe + 1] = i end
    end

    local after = {}
    if #safe > 2 then
        for i = #safe, 2, -1 do local j = rng(1, i); safe[i], safe[j] = safe[j], safe[i] end
        local cnt = math.min(rng(3, 8), #safe)
        for ii = 1, cnt do after[safe[ii]] = true end
    end

    local result = {}
    for i = 1, #lines do
        if after[i] then
            result[#result + 1] = "if " .. opaque() .. " then"
            result[#result + 1] = lines[i]
            result[#result + 1] = "end"
        else
            result[#result + 1] = lines[i]
        end
    end
    return utils.joinLines(result)
end
