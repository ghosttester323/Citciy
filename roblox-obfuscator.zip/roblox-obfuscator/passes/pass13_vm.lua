----------------------------------------------------------------
-- PASS 13: CUSTOM VM (function dispatch, NO loadstring)
--
-- Splits code into chunks, wraps each as a closure in a shuffled
-- function table, adds junk entries, and builds a dispatch loop.
-- NO loadstring — all execution via direct function calls.
----------------------------------------------------------------
return function(source, env)
    local rng = env.prng.rng
    local genName = env.naming.genName
    local pick = env.prng.pick
    local tokenize = env.tokenizer.tokenize
    local toSource = env.tokenizer.toSource
    local TK_KW = env.tokenizer.TK_KW
    local TK_WS = env.tokenizer.TK_WS
    local TK_OP = env.tokenizer.TK_OP
    local TK_ID = env.tokenizer.TK_ID

    -- Step 1: Split source into chunks at depth-0 boundaries
    local lines = {}
    for line in source:gmatch("[^\n]+") do lines[#lines + 1] = line end
    if #lines == 0 then return source end

    local function depthChange(line)
        local t = line:match("^%s*(.-)%s*$")
        if t:match("^elseif") or t == "else" then return 0 end
        local d = 0
        for w in t:gmatch("%S+") do
            if w == "function" or w == "then" or w == "do" or w == "repeat" then
                d = d + 1
            elseif w == "end" or w == "until" then
                d = d - 1
            end
        end
        return d
    end

    local chunks = {}
    local current = {}
    local depth = 0
    for _, line in ipairs(lines) do
        current[#current + 1] = line
        depth = depth + depthChange(line)
        if depth <= 0 and #current > 0 then
            chunks[#chunks + 1] = table.concat(current, "\n")
            current = {}; depth = 0
        end
    end
    if #current > 0 then
        chunks[#chunks + 1] = table.concat(current, "\n")
    end
    if #chunks == 0 then return source end

    -- Step 2: Transform each chunk — remove top-level 'local', collect declared names
    local transformedChunks = {}
    local allDeclared = {}

    for _, chunkSrc in ipairs(chunks) do
        local toks = tokenize(chunkSrc)
        local result = {}
        local d = 0
        local afterElseIf = false

        for idx, tk in ipairs(toks) do
            if tk.t == TK_KW then
                if tk.v == "elseif" then
                    afterElseIf = true
                    result[#result + 1] = tk
                elseif tk.v == "then" then
                    if afterElseIf then afterElseIf = false
                    else d = d + 1 end
                    result[#result + 1] = tk
                elseif tk.v == "else" then
                    afterElseIf = false
                    result[#result + 1] = tk
                elseif tk.v == "function" then
                    d = d + 1
                    result[#result + 1] = tk
                elseif tk.v == "do" or tk.v == "repeat" then
                    d = d + 1
                    result[#result + 1] = tk
                elseif tk.v == "end" then
                    d = d - 1
                    result[#result + 1] = tk
                elseif tk.v == "until" then
                    d = d - 1
                    result[#result + 1] = tk
                elseif tk.v == "local" and d == 0 then
                    local j = idx + 1
                    while j <= #toks and toks[j].t == TK_WS do j = j + 1 end
                    if j <= #toks and toks[j].t == TK_KW and toks[j].v == "function" then
                        local k = j + 1
                        while k <= #toks and toks[k].t == TK_WS do k = k + 1 end
                        if k <= #toks and toks[k].t == TK_ID then
                            allDeclared[toks[k].v] = true
                        end
                    elseif j <= #toks and toks[j].t == TK_ID then
                        local k = j
                        allDeclared[toks[k].v] = true
                        k = k + 1
                        while k <= #toks do
                            while k <= #toks and toks[k].t == TK_WS do k = k + 1 end
                            if k <= #toks and toks[k].t == TK_OP and toks[k].v == "," then
                                k = k + 1
                                while k <= #toks and toks[k].t == TK_WS do k = k + 1 end
                                if k <= #toks and toks[k].t == TK_ID then
                                    allDeclared[toks[k].v] = true; k = k + 1
                                end
                            else break end
                        end
                    else
                        result[#result + 1] = tk
                    end
                else
                    result[#result + 1] = tk
                end
            else
                result[#result + 1] = tk
            end
        end
        transformedChunks[#transformedChunks + 1] = toSource(result)
    end

    -- Step 3: Generate VM output
    local declaredNames = {}
    for name, _ in pairs(allDeclared) do declaredNames[#declaredNames + 1] = name end

    local function junkFunc()
        local a = genName()
        return pick({
            "function() local " .. a .. "=0 end",
            "function() local " .. a .. "={} end",
            "function() if (not false) then end end",
            "function() local " .. a .. "=type(nil) end",
            "function() return nil end",
            "function() local " .. a .. "=1 for " .. genName() .. "=1," .. a .. " do " .. a .. "=" .. a .. "+0 end end",
            "function() local " .. a .. "={1,2,3} for " .. genName() .. "=1,#" .. a .. " do end end",
            "function() local " .. a .. "=0 for " .. genName() .. "=1,10 do " .. a .. "=" .. a .. "+" .. rng(1, 9) .. "-" .. rng(1, 9) .. " end end",
            "function() local " .. a .. "=type(" .. rng(1, 999) .. ") end",
        })
    end

    -- Build entries: real chunks + junk
    local allEntries = {}
    for cidx, chunk in ipairs(transformedChunks) do
        allEntries[#allEntries + 1] = { real = true, idx = cidx, data = "function() " .. chunk .. " end" }
    end
    local junkCount = rng(math.max(3, math.floor(#chunks * 0.7)), math.floor(#chunks * 1.5))
    for _ = 1, junkCount do
        allEntries[#allEntries + 1] = { real = false, data = junkFunc() }
    end

    -- Shuffle all entries
    for i = #allEntries, 2, -1 do
        local j = rng(1, i)
        allEntries[i], allEntries[j] = allEntries[j], allEntries[i]
    end

    -- Build execution order
    local order = {}
    for pos, entry in ipairs(allEntries) do
        if entry.real then
            order[entry.idx] = pos
        end
    end

    local vmVar = genName()
    local ordVar = genName()
    local iVar = genName()
    local outerFn = genName()

    local entryStrs = {}
    for _, entry in ipairs(allEntries) do
        entryStrs[#entryStrs + 1] = entry.data
    end

    local orderStrs = {}
    for i = 1, #chunks do
        orderStrs[#orderStrs + 1] = tostring(order[i])
    end

    local out = {}
    out[#out + 1] = "local function " .. outerFn .. "()"
    if #declaredNames > 0 then
        out[#out + 1] = "local " .. table.concat(declaredNames, ",")
    end
    out[#out + 1] = "local " .. vmVar .. "={" .. table.concat(entryStrs, ",") .. "}"
    out[#out + 1] = "local " .. ordVar .. "={" .. table.concat(orderStrs, ",") .. "}"
    out[#out + 1] = "for " .. iVar .. "=1,#" .. ordVar .. " do " .. vmVar .. "[" .. ordVar .. "[" .. iVar .. "]]() end"
    out[#out + 1] = "end"
    out[#out + 1] = outerFn .. "()"

    return table.concat(out, "\n")
end
