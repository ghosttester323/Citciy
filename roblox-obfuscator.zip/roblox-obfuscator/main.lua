--[[
    ╔═══════════════════════════════════════════════════════════╗
    ║   ROBLOX LUA OBFUSCATOR v6.0 — MODULAR EDITION           ║
    ║   16 Passes · Custom VM · NO loadstring · NO XOR          ║
    ║   Usage: lua main.lua <input> <output> [--level] [--seed] ║
    ╚═══════════════════════════════════════════════════════════╝

    Structure:
      main.lua              — Entry point, CLI, orchestrator
      core/
        prng.lua            — Seeded PRNG (setseed, rng, pick)
        reserved.lua        — Protected names (Roblox globals, keywords, API)
        naming.lua          — Variable name generator (genName)
        tokenizer.lua       — Hand-written Lua lexer + helpers
        utils.lua           — Shared helpers (isSafeLine, opaque, splitLines)
      passes/
        pass01_remove_comments.lua
        pass02_rename.lua
        pass03_constant_array.lua
        pass04_string_encrypt.lua
        pass05_control_flow.lua
        pass06_dead_functions.lua
        pass07_wrapper.lua
        pass08_number_arith.lua
        pass09_boolean_encode.lua
        pass10_member_index.lua
        pass11_cond_wrap.lua
        pass12_anti_format.lua
        pass13_vm.lua
        pass14_proxy.lua
        pass15_string_split.lua
        pass16_advanced_junk.lua
]]

----------------------------------------------------------------
-- PATH RESOLUTION
-- Works no matter where you invoke lua from
----------------------------------------------------------------
local BASE_DIR = (arg and arg[0]) or "./main.lua"
BASE_DIR = BASE_DIR:match("(.*[/\\])")
if not BASE_DIR then BASE_DIR = "./" end
-- Remove trailing separator for clean concatenation
BASE_DIR = BASE_DIR:gsub("[/\\]$", "")

local function corePath(name) return BASE_DIR .. "/core/" .. name .. ".lua" end
local function passPath(name) return BASE_DIR .. "/passes/" .. name .. ".lua" end

----------------------------------------------------------------
-- LOAD CORE MODULES
----------------------------------------------------------------
local prng      = dofile(corePath("prng"))
local reserved  = dofile(corePath("reserved"))
local naming    = dofile(corePath("naming"))
local tokenizer = dofile(corePath("tokenizer"))
local utils     = dofile(corePath("utils"))

-- Initialize naming with reserved list
naming.init(reserved)

-- Shared environment passed to every pass
local env = {
    prng      = prng,
    reserved  = reserved,
    naming    = naming,
    tokenizer = tokenizer,
    utils     = utils,
}

----------------------------------------------------------------
-- LOAD ALL 16 PASSES
----------------------------------------------------------------
local passes = {}

passes[1]  = dofile(passPath("pass01_remove_comments"))    -- tokens in → tokens out
passes[2]  = dofile(passPath("pass02_rename"))              -- tokens in → tokens out
passes[3]  = dofile(passPath("pass03_constant_array"))      -- tokens in → tokens out
passes[4]  = dofile(passPath("pass04_string_encrypt"))      -- tokens in → tokens out
passes[5]  = dofile(passPath("pass05_control_flow"))        -- source in → source out
passes[6]  = dofile(passPath("pass06_dead_functions"))      -- source in → source out
passes[7]  = dofile(passPath("pass07_wrapper"))             -- source in → source out
passes[8]  = dofile(passPath("pass08_number_arith"))        -- tokens in → tokens out
passes[9]  = dofile(passPath("pass09_boolean_encode"))      -- tokens in → tokens out
passes[10] = dofile(passPath("pass10_member_index"))        -- tokens in → tokens out
passes[11] = dofile(passPath("pass11_cond_wrap"))           -- source in → source out
passes[12] = dofile(passPath("pass12_anti_format"))         -- source in → source out
passes[13] = dofile(passPath("pass13_vm"))                  -- source in → source out
passes[14] = dofile(passPath("pass14_proxy"))               -- source in → source out
passes[15] = dofile(passPath("pass15_string_split"))        -- tokens in → tokens out
passes[16] = dofile(passPath("pass16_advanced_junk"))       -- source in → source out

----------------------------------------------------------------
-- PASS METADATA
----------------------------------------------------------------
local TOTAL_PASSES = 16

local PASS_NAMES = {
    [1]  = "Removing comments",
    [2]  = "Renaming variables",
    [3]  = "Building constant array",
    [4]  = "Encrypting strings",
    [5]  = "Obfuscating control flow",
    [6]  = "Injecting dead functions",
    [7]  = "Wrapper encapsulation",
    [8]  = "Number arithmetic encoding",
    [9]  = "Boolean encoding",
    [10] = "Member index obfuscation",
    [11] = "Conditional wrapping",
    [12] = "Anti-formatting",
    [13] = "Custom VM (function dispatch, NO loadstring)",
    [14] = "Proxy functions",
    [15] = "String splitting",
    [16] = "Advanced junk injection",
}

-- Source-level passes (receive/return source string instead of tokens)
local SOURCE_PASSES = {
    [5] = true, [6] = true, [7] = true, [11] = true,
    [12] = true, [13] = true, [14] = true, [16] = true,
}

----------------------------------------------------------------
-- OBFUSCATE FUNCTION
----------------------------------------------------------------
local function obfuscate(source, config)
    local passList = config.passes or {1,2,10,8,15,3,4,9,14,5,6,16,11,13,7,12}
    prng.setseed(config.seed or os.time())

    print("  [*] Tokenizing...")
    local toks = tokenizer.tokenize(source)
    print("  [*] " .. #toks .. " tokens")

    for idx, pn in ipairs(passList) do
        local name = PASS_NAMES[pn] or ("Pass " .. pn)
        local fn = passes[pn]
        if not fn then
            print("  [PASS " .. pn .. "/" .. TOTAL_PASSES .. "]  SKIP (not loaded)")
        elseif SOURCE_PASSES[pn] then
            -- Source-level pass: convert tokens → source, run pass, re-tokenize
            print("  [PASS " .. pn .. "/" .. TOTAL_PASSES .. "]  " .. name .. "...")
            local src = tokenizer.toSource(toks)
            src = fn(src, env)
            toks = tokenizer.tokenize(src)
        else
            -- Token-level pass: operate directly on token array
            print("  [PASS " .. pn .. "/" .. TOTAL_PASSES .. "]  " .. name .. "...")
            toks = fn(toks, env)
        end
    end

    print("  [*] Formatting...")
    return tokenizer.formatOutput(toks)
end

----------------------------------------------------------------
-- CLI
----------------------------------------------------------------
local function banner()
    print([[
╔═══════════════════════════════════════════════════════════╗
║     ROBLOX LUA OBFUSCATOR v6.0 — MODULAR EDITION         ║
║     16 Passes · Custom VM · NO loadstring · NO XOR        ║
╚═══════════════════════════════════════════════════════════╝
]])
end

local function main(...)
    local args = {...}
    local input, output, seedVal, level, passStr = nil, nil, nil, 3, nil
    local i = 1
    while i <= #args do
        local a = args[i]
        if a == "--help" or a == "-h" then
            banner()
            print("Usage: lua main.lua <input> <output> [options]\n")
            print("Options:")
            print("  --seed <N>       Random seed")
            print("  --level <1-3>    Level (1=light 2=medium 3=max)")
            print("  --passes <list>  Comma-separated pass numbers\n")
            print("Passes:")
            for p = 1, TOTAL_PASSES do
                local info = PASS_NAMES[p] or "Unknown"
                print("  " .. string.format("%2d", p) .. " " .. info)
            end
            print("\nLevels:")
            print("  1 = Light   (1, 2, 4, 9, 15)")
            print("  2 = Medium  (1, 2, 4, 5, 9, 10, 14, 15)")
            print("  3 = MAX     (all 16 passes, VM before wrapper)")
            return
        elseif a == "--seed" then i = i + 1; seedVal = tonumber(args[i])
        elseif a == "--level" then i = i + 1; level = tonumber(args[i])
        elseif a == "--passes" then i = i + 1; passStr = args[i]
        elseif not input then input = a
        elseif not output then output = a
        end
        i = i + 1
    end

    if not input or not output then
        banner(); print("Usage: lua main.lua <input> <output>\n"); return
    end

    local f = io.open(input, "r")
    if not f then print("ERROR: Cannot open " .. input); return end
    local source = f:read("*a"); f:close()

    -- Parse pass list
    local passList = nil
    if passStr then
        passList = {}
        for p in passStr:gmatch("%d+") do passList[#passList + 1] = tonumber(p) end
    end

    if not passList then
        if level == 1 then passList = {1, 2, 4, 9, 15}
        elseif level == 2 then passList = {1, 2, 4, 5, 9, 10, 14, 15}
        else passList = {1, 2, 10, 8, 15, 3, 4, 9, 14, 5, 6, 16, 11, 13, 7, 12}
        end
    end

    -- Ensure VM runs before wrapper (pass 7) if both present
    local hasVM = false
    local hasWrapper = false
    for _, p in ipairs(passList) do
        if p == 13 then hasVM = true end
        if p == 7 then hasWrapper = true end
    end
    if hasVM then
        local newPassList = {}
        for _, p in ipairs(passList) do
            if p ~= 13 then newPassList[#newPassList + 1] = p end
        end
        if hasWrapper then
            local insertPos = #newPassList + 1
            for idx, p in ipairs(newPassList) do
                if p == 7 then insertPos = idx; break end
            end
            table.insert(newPassList, insertPos, 13)
        else
            newPassList[#newPassList + 1] = 13
        end
        passList = newPassList
    end

    banner()
    print("  Input:  " .. input .. " (" .. #source .. " bytes)")
    print("  Output: " .. output)
    print("  Seed:   " .. tostring(seedVal or "random"))
    print("  Passes: " .. table.concat(passList, ", ") .. "\n")

    local result = obfuscate(source, { seed = seedVal, passes = passList })
    local of = io.open(output, "w")
    if not of then print("ERROR: Cannot write " .. output); return end
    of:write(result); of:close()

    print("\n  [OK] " .. output .. " (" .. #result .. " bytes, "
        .. math.floor(#result / math.max(1, #source) * 100) .. "%)")
end

----------------------------------------------------------------
-- ENTRY POINT
----------------------------------------------------------------
if arg and #arg > 0 then
    main(table.unpack(arg))
end

return { obfuscate = obfuscate, env = env }
