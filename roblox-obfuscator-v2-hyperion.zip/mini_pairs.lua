local names = {"Alice", "Bob", "Charlie"}
for idx, name in pairs(names) do
    print("Player " .. idx .. ": " .. name)
end
