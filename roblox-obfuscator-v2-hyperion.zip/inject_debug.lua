local content = io.open('t.lua','r'):read('*a')

-- Add max steps protection
content = content:gsub(
  "Cl=1",
  "local _dbgSteps=0 Cl=1"
)
content = content:gsub(
  "while Cl<=#",
  "_dbgSteps=_dbgSteps+1 if _dbgSteps>5000 then print('INFINITE LOOP pc='..Cl) return nil end while Cl<=#"
)

-- Add debug for key opcodes
content = content:gsub(
  "elseif Hl==36 then",
  "elseif Hl==36 then print('CLOSURE ra='..Kl..' bv='..tostring(Tl))"
)
content = content:gsub(
  "elseif Hl==27 then return",
  "elseif Hl==27 then print('RETURN ra='..Kl..' val='..tostring(Dl[Kl])) return"
)
content = content:gsub(
  "elseif Hl==26 then",
  "elseif Hl==26 then print('CALL ra='..Kl..' nargs='..Rl..' funcType='..type(Dl[Kl]))"
)

io.open('t_debug.lua','w'):write(content):close()
