local ll={44619,22828,22637,42777,36843,14167,53870,29590,21814,1311,61153,53215,723,4990,54884,2096,23796,42169,56712,64384,42538,11429,58498,52608,31580,9179,19468,24023,30402,12139,5447,4188,37004,7238,30244,54245,56791,57536,28966,62592,7073,10794,46626,8653,48370,44106,23749,13432,22243,44989,2284078407,69871432,2217124237,70162607,2217091328,70399443,2217115855,270570761,273168249,271898227,138200054,2754924889,2553561138,272680547,272926566,1884203341,72538587,273990755,73033164,274524141,1348503995,1348744524,1349005990,273679260,1749831097,1409513834,1811946977}
local Ol={44610,22839,22637,42776,36778,14139,53767,29685,21843,1311,61153,53214,722,4924,54795,2130,23796,42169,56714,64385,42601,11469,58595,52722,31536,9138,19561,24023,30402,12136,5446,4140,37118,7215,30282,54161,56791,57537,29046,62700,7104,10835,46663,8639,48338,44106,23748,13378,22211,44989,17735,9544,42375,40623,10507,16339,36035,34569,10105,62067,50166,53593,23602,55907,39270,42829,51675,58467,30668,50669,42412,8020,6847,14236,20408,40085,7649,12749,1018,64031,21195,4741,36899,62050,2489,47507,6694,3551,14581,14738,17279,53890,12037,7323,13639,36037,48019,14539,24825,3718,64288,20600,514,65442,12649}
local function Il(ll,Ol)
local Ql={}
for Wl=1,#ll do Ql[Wl]=math.floor(ll[Wl]~Ol[(((Wl-1)%#Ol)+1)]) end
local function Sl(off)
local ct={} local nc2=Ql[off] off=off+1 local ni2=Ql[off] off=off+1 local ns2=Ql[off] off=off+1
for i=1,nc2 do local t=Ql[off] off=off+1
if t==0 then ct[i]=Ql[off] off=off+1
elseif t==1 then local s='' while true do local v=Ql[off] off=off+1 if v==0 then break end s=s..string.char(v) end ct[i]=s
elseif t==2 then ct[i]=(Ql[off]==1) off=off+1
else off=off+1 end end
local ix={}
for i=1,ni2 do ix[i]=Ql[off] off=off+1 end
local sb={}
for i=1,ns2 do local sl=Ql[off] off=off+1 sb[i]=Sl(off) off=sb[i].off end
return {ct=ct,ix=ix,sb=sb,off=off}
end
local function El(Pl,parentR)
local Dl={}
for i=0,255 do Dl[i]=nil end
Dl[1]=true Dl[2]=false
if parentR then for i=0,255 do Dl[i]=parentR[i] end end
local Gl=Pl.ct
local Bl=Pl.ix
local Cl=1
while Cl<=#Bl do
local w=Bl[Cl]
local Hl=math.floor(w/67108864)%64
local Kl=math.floor(w/262144)%256
local Rl=math.floor(w/512)%512
local Fl=w%512
local Tl=Rl>=256 and Gl[Rl-256] or Dl[Rl]
local Yl=Fl>=256 and Gl[Fl-256] or Dl[Fl]
if Hl==0 then Cl=Cl+1
elseif Hl==1 then Dl[Kl]=Tl Cl=Cl+1
elseif Hl==2 then Dl[Kl]=nil Cl=Cl+1
elseif Hl==3 then Dl[Kl]=(Rl==1) Cl=Cl+1
elseif Hl==4 then Dl[Kl]=Dl[Rl] Cl=Cl+1
elseif Hl==5 then Dl[Kl]=-Dl[Rl] Cl=Cl+1
elseif Hl==6 then Dl[Kl]=Dl[Rl]+Yl Cl=Cl+1
elseif Hl==7 then Dl[Kl]=Dl[Rl]-Yl Cl=Cl+1
elseif Hl==8 then Dl[Kl]=Dl[Rl]*Yl Cl=Cl+1
elseif Hl==9 then Dl[Kl]=Dl[Rl]/Yl Cl=Cl+1
elseif Hl==10 then Dl[Kl]=Dl[Rl]%Yl Cl=Cl+1
elseif Hl==11 then Dl[Kl]=Dl[Rl]^Yl Cl=Cl+1
elseif Hl==12 then Dl[Kl]=(Dl[Rl]==Yl) Cl=Cl+1
elseif Hl==13 then Dl[Kl]=(Dl[Rl]<Yl) Cl=Cl+1
elseif Hl==14 then Dl[Kl]=(Dl[Rl]<=Yl) Cl=Cl+1
elseif Hl==15 then Dl[Kl]=(Dl[Rl]~=Yl) Cl=Cl+1
elseif Hl==16 then Dl[Kl]=(not Dl[Rl]) Cl=Cl+1
elseif Hl==17 then Dl[Kl]=Dl[Rl] and Yl Cl=Cl+1
elseif Hl==18 then Dl[Kl]=Dl[Rl] or Yl Cl=Cl+1
elseif Hl==19 then Dl[Kl]=#Dl[Rl] Cl=Cl+1
elseif Hl==20 then Dl[Kl]=tostring(Dl[Rl])..tostring(Yl) Cl=Cl+1
elseif Hl==21 then local Ul=Rl+Fl*512 if Ul>=131072 then Ul=Ul-262144 end Cl=Cl+1+Ul
elseif Hl==22 then local Ul=Rl+Fl*512 if Ul>=131072 then Ul=Ul-262144 end if not Dl[Kl] then Cl=Cl+1+Ul else Cl=Cl+1 end
elseif Hl==23 then local Ul=Rl+Fl*512 if Ul>=131072 then Ul=Ul-262144 end if Dl[Kl] then Cl=Cl+1+Ul else Cl=Cl+1 end
elseif Hl==24 then local Ul=Rl+Fl*512 if Ul>=131072 then Ul=Ul-262144 end if(Dl[Kl]-Dl[Kl+2])>Dl[Kl+1] then Cl=Cl+1+Ul else Cl=Cl+1 end
elseif Hl==25 then local Ul=Rl+Fl*512 if Ul>=131072 then Ul=Ul-262144 end Dl[Kl]=Dl[Kl]+Dl[Kl+2] if(Dl[Kl+2]>0 and Dl[Kl]<=Dl[Kl+1]) or(Dl[Kl+2]<=0 and Dl[Kl]>=Dl[Kl+1]) then Cl=Cl+Ul else Cl=Cl+1 end
elseif Hl==26 then local ag={} for ai=1,Rl do ag[ai]=Dl[Kl+ai] end local rt=Dl[Kl](table.unpack(ag)) Dl[Kl]=rt Cl=Cl+1
elseif Hl==27 then return Dl[Kl]
elseif Hl==28 then Dl[Kl]=_G[Tl] Cl=Cl+1
elseif Hl==29 then _G[Tl]=Dl[Kl] Cl=Cl+1
elseif Hl==30 then Dl[Kl]=Dl[Rl][Yl] Cl=Cl+1
elseif Hl==31 then Dl[Kl][Tl]=Yl Cl=Cl+1
elseif Hl==32 then Dl[Kl]=Dl[Rl][Yl] Cl=Cl+1
elseif Hl==33 then Dl[Kl][Tl]=Dl[Fl] Cl=Cl+1
elseif Hl==34 then Dl[Kl]={} Cl=Cl+1
elseif Hl==35 then Cl=Cl+1
elseif Hl==36 then local sp=Pl.sb[Tl] local cr={} for ci=0,255 do cr[ci]=Dl[ci] end Dl[Kl]=function(...) local nr={} for ni=0,255 do nr[ni]=cr[ni] end local ca={...} for ai=1,#ca do nr[7+ai]=ca[ai] end return El(sp,nr) end Cl=Cl+1
elseif Hl==37 then Dl[Kl]=type(Dl[Rl]) Cl=Cl+1
elseif Hl==38 then local Ul=Rl+Fl*512 if Ul>=131072 then Ul=Ul-262144 end local ok2,vl=next(Dl[Kl+1],Dl[Kl+3]) if ok2 then Dl[Kl+2]=ok2 Dl[Kl+3]=vl Cl=Cl+Ul else Cl=Cl+1 end
elseif Hl==39 then Dl[Kl]=tonumber(Dl[Rl]) Cl=Cl+1
elseif Hl==40 then Dl[Kl]=tostring(Dl[Rl]) Cl=Cl+1
elseif Hl==41 then Dl[Kl+3]=nil Cl=Cl+1
else Cl=Cl+1 end
end
return nil
end
local mp=Sl(1)
El(mp)
end
Il(ll,Ol)
