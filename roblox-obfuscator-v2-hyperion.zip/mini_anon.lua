print((function() return "test" end)())
