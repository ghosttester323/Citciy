local ll={44608,22834,22636,42777,36826,14153,53870,29595,21799,1311,61153,53215,1881276626,2418415420,1747244554,1746930259,1811963124,42161,56715,64386,42601,11469,58569,69390322,1814067504,1811948466}
local Ol={44610,22839,22637,42776,36778,14139,53767,29685,21843,1311,61153,53214,722,4924,54795,2130,23796,42169,56714,64385,42601,11469,58595,52722,31536,9138,19561,24023,30402,12136,5446,4140,37118,7215,30282,54161,56791,57537,29046,62700,7104,10835,46663,8639,48338,44106,23748,13378,22211,44989,17735,9544,42375,40623}
local function Il(ll,Ol)
local Ql={}
for Wl=1,#ll do Ql[Wl]=math.floor(ll[Wl]~Ol[(((Wl-1)%#Ol)+1)]) end
local function Sl(off)
local ct={} local nc2=Ql[off] off=off+1 local ni2=Ql[off] off=off+1 local ns2=Ql[off] off=off+1
for i=1,nc2 do local t=Ql[off] off=off+1
if t==0 then ct[i]=Ql[off] off=off+1
elseif t==1 then local s='' while true do local v=Ql[off] off=off+1 if v==0 then break end s=s..string.char(v) end ct[i]=s
elseif t==2 then ct[i]=(Ql[off]==1) off=off+1
else off=off+1 end end
local ix={}
for i=1,ni2 do ix[i]=Ql[off] off=off+1 end
local sb={}
for i=1,ns2 do local sl=Ql[off] off=off+1 sb[i]=Sl(off) off=sb[i].off end
return {ct=ct,ix=ix,sb=sb,off=off}
end
local function El(Pl,parentR)
local Dl={}
for i=0,255 do Dl[i]=nil end
Dl[1]=true Dl[2]=false
if parentR then for i=0,255 do Dl[i]=parentR[i] end end
local Gl=Pl.ct
local Bl=Pl.ix
local _dbgSteps=0 Cl=1
_dbgSteps=_dbgSteps+1 if _dbgSteps>50 then print('TOO MANY') return nil end while Cl<=#Bl do
if _dbgSteps<=30 then print('OUTER exec: pc='..Cl..' step='.._dbgSteps) end local w=Bl[Cl]
Hl=math.floor(w/67108864)%64
Kl=math.floor(w/262144)%256
Rl=math.floor(w/512)%512
Fl=w%512
Tl=Rl>=256 and Gl[Rl-256] or Dl[Rl]
Yl=Fl>=256 and Gl[Fl-256] or Dl[Fl]
if Hl==0 then Cl=Cl+1
elseif Hl==1 then Dl[Kl]=Tl Cl=Cl+1
elseif Hl==2 then Dl[Kl]=nil Cl=Cl+1
elseif Hl==3 then Dl[Kl]=(Rl==1) Cl=Cl+1
elseif Hl==4 then Dl[Kl]=Dl[Rl] Cl=Cl+1
elseif Hl==5 then Dl[Kl]=-Dl[Rl] Cl=Cl+1
elseif Hl==6 then Dl[Kl]=Dl[Rl]+Yl Cl=Cl+1
elseif Hl==7 then Dl[Kl]=Dl[Rl]-Yl Cl=Cl+1
elseif Hl==8 then Dl[Kl]=Dl[Rl]*Yl Cl=Cl+1
elseif Hl==9 then Dl[Kl]=Dl[Rl]/Yl Cl=Cl+1
elseif Hl==10 then Dl[Kl]=Dl[Rl]%Yl Cl=Cl+1
elseif Hl==11 then Dl[Kl]=Dl[Rl]^Yl Cl=Cl+1
elseif Hl==12 then Dl[Kl]=(Dl[Rl]==Yl) Cl=Cl+1
elseif Hl==13 then Dl[Kl]=(Dl[Rl]<Yl) Cl=Cl+1
elseif Hl==14 then Dl[Kl]=(Dl[Rl]<=Yl) Cl=Cl+1
elseif Hl==15 then Dl[Kl]=(Dl[Rl]~=Yl) Cl=Cl+1
elseif Hl==16 then Dl[Kl]=(not Dl[Rl]) Cl=Cl+1
elseif Hl==17 then Dl[Kl]=Dl[Rl] and Yl Cl=Cl+1
elseif Hl==18 then Dl[Kl]=Dl[Rl] or Yl Cl=Cl+1
elseif Hl==19 then Dl[Kl]=#Dl[Rl] Cl=Cl+1
elseif Hl==20 then Dl[Kl]=tostring(Dl[Rl])..tostring(Yl) Cl=Cl+1
elseif Hl==21 then Ul=Rl+Fl*512 if Ul>=131072 then Ul=Ul-262144 end Cl=Cl+1+Ul
elseif Hl==22 then Ul=Rl+Fl*512 if Ul>=131072 then Ul=Ul-262144 end if not Dl[Kl] then Cl=Cl+1+Ul else Cl=Cl+1 end
elseif Hl==23 then Ul=Rl+Fl*512 if Ul>=131072 then Ul=Ul-262144 end if Dl[Kl] then Cl=Cl+1+Ul else Cl=Cl+1 end
elseif Hl==24 then Ul=Rl+Fl*512 if Ul>=131072 then Ul=Ul-262144 end if(Dl[Kl]-Dl[Kl+2])>Dl[Kl+1] then Cl=Cl+1+Ul else Cl=Cl+1 end
elseif Hl==25 then Ul=Rl+Fl*512 if Ul>=131072 then Ul=Ul-262144 end Dl[Kl]=Dl[Kl]+Dl[Kl+2] if(Dl[Kl+2]>0 and Dl[Kl]<=Dl[Kl+1]) or(Dl[Kl+2]<=0 and Dl[Kl]>=Dl[Kl+1]) then Cl=Cl+Ul else Cl=Cl+1 end
elseif Hl==26 then local ag={} for ai=1,Rl do ag[ai]=Dl[Kl+ai] end local rt=Dl[Kl](table.unpack(ag)) Dl[Kl]=rt Cl=Cl+1
elseif Hl==27 then return Dl[Kl]
elseif Hl==28 then Dl[Kl]=_G[Tl] Cl=Cl+1
elseif Hl==29 then _G[Tl]=Dl[Kl] Cl=Cl+1
elseif Hl==30 then Dl[Kl]=Dl[Rl][Yl] Cl=Cl+1
elseif Hl==31 then Dl[Kl][Tl]=Yl Cl=Cl+1
elseif Hl==32 then Dl[Kl]=Dl[Rl][Yl] Cl=Cl+1
elseif Hl==33 then Dl[Kl][Tl]=Dl[Fl] Cl=Cl+1
elseif Hl==34 then Dl[Kl]={} Cl=Cl+1
elseif Hl==35 then Cl=Cl+1
elseif Hl==36 then local sp=Pl.sb[Tl] local cr={} for ci=0,255 do cr[ci]=Dl[ci] end Dl[Kl]=function(...) local nr={} for ni=0,255 do nr[ni]=cr[ni] end local ca={...} for ai=1,#ca do nr[7+ai]=ca[ai] end return El(sp,nr) end Cl=Cl+1
elseif Hl==37 then Dl[Kl]=type(Dl[Rl]) Cl=Cl+1
elseif Hl==38 then Ul=Rl+Fl*512 if Ul>=131072 then Ul=Ul-262144 end local ok2,vl=next(Dl[Kl+1],Dl[Kl+3]) if ok2 then Dl[Kl+2]=ok2 Dl[Kl+3]=vl Cl=Cl+Ul else Cl=Cl+1 end
elseif Hl==39 then Dl[Kl]=tonumber(Dl[Rl]) Cl=Cl+1
elseif Hl==40 then Dl[Kl]=tostring(Dl[Rl]) Cl=Cl+1
elseif Hl==41 then Dl[Kl+3]=nil Cl=Cl+1
else Cl=Cl+1 end
end
return nil
end
local mp=Sl(1)
El(mp)
end
Il(ll,Ol)
