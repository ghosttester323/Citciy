local s = string print(s)
