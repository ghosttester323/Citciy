local function count(n)
    if n <= 0 then return 999 end
    return count(n - 1)
end
print("count(3) = " .. tostring(count(3)))
