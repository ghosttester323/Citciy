local content = io.open('t.lua','r'):read('*a')

-- Add step counter
content = content:gsub(
  "Cl=1",
  "local _dbgSteps=0 Cl=1"
)
content = content:gsub(
  "while Cl<=#",
  "_dbgSteps=_dbgSteps+1 if _dbgSteps>50 then print('TOO MANY') return nil end while Cl<=#"
)

-- Add Cl tracking before the while loop condition check
-- We need to add the print INSIDE the exec function right after Cl increment
-- Let's just add it at the top of the while loop
content = content:gsub(
  "local w=",
  "if _dbgSteps<=30 then print('OUTER exec: pc='..Cl..' step='.._dbgSteps) end local w="
)

io.open('t_debug.lua','w'):write(content):close()
