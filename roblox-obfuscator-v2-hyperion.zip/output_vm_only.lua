local ll={6254,10883,53156,55352,31539,64287,9080,10700,53305,25427,14262,63520,42538,2435,46102,185,43243,42065,45031,27191,36466,24185,12384,12599,19256,63510,51855,57809,10637,450,22550,28240,6909,57128,31845,45093,25609,34789,65246,23896,659,9712,45297,64382,24850,437,54853,42022,1881322938,69659546,1746951114,70166187,271068943,70653115,271592874,1882891612,71233299,272688708,272954341,407399876,1347159486,272421179,1748555334,1811969501}
local Ol={6251,10899,53156,55353,31555,64365,8977,10658,53325,25427,14263,63592,42575,2543,46202,214,43211,42039,44949,27224,36383,24153,12303,12629,19294,63587,51964,57778,10732,438,22649,28194,6876,57128,31845,45103,25609,34812,65247,23818,758,9603,45188,64274,24934,399,54885,42022,47034,61338,22987,41131,14607,7355,14250,42844,58643,62020,60389,19925,7084,63291,54343,30173,20039,56448,51005,50038,27392,8120,23125,59302,56694,61690,5240,19460,16748,18241,2022,60161,41760,20364,36852,24828,59755,8918,11912,516,50589,28345,17745,107,50454,64736}
local function Il(ll,Ol)
local Ql={}
for Wl=1,#ll do Ql[Wl]=math.floor(ll[Wl]~Ol[(((Wl-1)%#Ol)+1)]) end
local function Sl(off)
local ct={} local nc2=Ql[off] off=off+1 local ni2=Ql[off] off=off+1 local ns2=Ql[off] off=off+1
for i=1,nc2 do local t=Ql[off] off=off+1
if t==0 then ct[i]=Ql[off] off=off+1
elseif t==1 then local s='' while true do local v=Ql[off] off=off+1 if v==0 then break end s=s..string.char(v) end ct[i]=s
elseif t==2 then ct[i]=(Ql[off]==1) off=off+1
else off=off+1 end end
local ix={}
for i=1,ni2 do ix[i]=Ql[off] off=off+1 end
local sb={}
for i=1,ns2 do local sl=Ql[off] off=off+1 sb[i]=Sl(off) off=sb[i].off end
return {ct=ct,ix=ix,sb=sb,off=off}
end
local function El(Pl,parentR)
local Dl={}
for i=0,255 do Dl[i]=nil end
Dl[1]=true Dl[2]=false
if parentR then for i=0,255 do Dl[i]=parentR[i] end end
local Gl=Pl.ct
local Bl=Pl.ix
Cl=1
while Cl<=#Bl do
local w=Bl[Cl]
Hl=math.floor(w/67108864)%64
Kl=math.floor(w/262144)%256
Rl=math.floor(w/512)%512
Fl=w%512
Tl=Rl>=256 and Gl[Rl-256] or Dl[Rl]
Yl=Fl>=256 and Gl[Fl-256] or Dl[Fl]
if Hl==0 then Cl=Cl+1
elseif Hl==1 then Dl[Kl]=Tl Cl=Cl+1
elseif Hl==2 then Dl[Kl]=nil Cl=Cl+1
elseif Hl==3 then Dl[Kl]=(Rl==1) Cl=Cl+1
elseif Hl==4 then Dl[Kl]=Dl[Rl] Cl=Cl+1
elseif Hl==5 then Dl[Kl]=-Dl[Rl] Cl=Cl+1
elseif Hl==6 then Dl[Kl]=Dl[Rl]+Yl Cl=Cl+1
elseif Hl==7 then Dl[Kl]=Dl[Rl]-Yl Cl=Cl+1
elseif Hl==8 then Dl[Kl]=Dl[Rl]*Yl Cl=Cl+1
elseif Hl==9 then Dl[Kl]=Dl[Rl]/Yl Cl=Cl+1
elseif Hl==10 then Dl[Kl]=Dl[Rl]%Yl Cl=Cl+1
elseif Hl==11 then Dl[Kl]=Dl[Rl]^Yl Cl=Cl+1
elseif Hl==12 then Dl[Kl]=(Dl[Rl]==Yl) Cl=Cl+1
elseif Hl==13 then Dl[Kl]=(Dl[Rl]<Yl) Cl=Cl+1
elseif Hl==14 then Dl[Kl]=(Dl[Rl]<=Yl) Cl=Cl+1
elseif Hl==15 then Dl[Kl]=(Dl[Rl]~=Yl) Cl=Cl+1
elseif Hl==16 then Dl[Kl]=(not Dl[Rl]) Cl=Cl+1
elseif Hl==17 then Dl[Kl]=Dl[Rl] and Yl Cl=Cl+1
elseif Hl==18 then Dl[Kl]=Dl[Rl] or Yl Cl=Cl+1
elseif Hl==19 then Dl[Kl]=#Dl[Rl] Cl=Cl+1
elseif Hl==20 then Dl[Kl]=tostring(Dl[Rl])..tostring(Yl) Cl=Cl+1
elseif Hl==21 then Ul=Rl+Fl*512 if Ul>=131072 then Ul=Ul-262144 end Cl=Cl+1+Ul
elseif Hl==22 then Ul=Rl+Fl*512 if Ul>=131072 then Ul=Ul-262144 end if not Dl[Kl] then Cl=Cl+1+Ul else Cl=Cl+1 end
elseif Hl==23 then Ul=Rl+Fl*512 if Ul>=131072 then Ul=Ul-262144 end if Dl[Kl] then Cl=Cl+1+Ul else Cl=Cl+1 end
elseif Hl==24 then Ul=Rl+Fl*512 if Ul>=131072 then Ul=Ul-262144 end if(Dl[Kl]-Dl[Kl+2])>Dl[Kl+1] then Cl=Cl+1+Ul else Cl=Cl+1 end
elseif Hl==25 then Ul=Rl+Fl*512 if Ul>=131072 then Ul=Ul-262144 end Dl[Kl]=Dl[Kl]+Dl[Kl+2] if(Dl[Kl+2]>0 and Dl[Kl]<=Dl[Kl+1]) or(Dl[Kl+2]<=0 and Dl[Kl]>=Dl[Kl+1]) then Cl=Cl+Ul else Cl=Cl+1 end
elseif Hl==26 then local ag={} for ai=1,Rl do ag[ai]=Dl[Kl+ai] end local rt=Dl[Kl](table.unpack(ag)) Dl[Kl]=rt Cl=Cl+1
elseif Hl==27 then return Dl[Kl]
elseif Hl==28 then Dl[Kl]=_G[Tl] Cl=Cl+1
elseif Hl==29 then _G[Tl]=Dl[Kl] Cl=Cl+1
elseif Hl==30 then Dl[Kl]=Dl[Rl][Yl] Cl=Cl+1
elseif Hl==31 then Dl[Kl][Tl]=Yl Cl=Cl+1
elseif Hl==32 then Dl[Kl]=Dl[Rl][Tl] Cl=Cl+1
elseif Hl==33 then Dl[Kl][Tl]=Dl[Fl] Cl=Cl+1
elseif Hl==34 then Dl[Kl]={} Cl=Cl+1
elseif Hl==35 then Cl=Cl+1
elseif Hl==36 then local sp=Pl.sb[Tl] local cr={} for ci=0,255 do cr[ci]=Dl[ci] end Dl[Kl]=function(...) local nr={} for ni=0,255 do nr[ni]=cr[ni] end local ca={...} for ai=1,#ca do nr[7+ai]=ca[ai] end return El(sp,nr) end Cl=Cl+1
elseif Hl==37 then Dl[Kl]=type(Dl[Rl]) Cl=Cl+1
elseif Hl==38 then Ul=Rl+Fl*512 if Ul>=131072 then Ul=Ul-262144 end local ok2,vl=next(Dl[Kl+1],Dl[Kl+3]) if ok2 then Dl[Kl+2]=ok2 Dl[Kl+3]=vl Cl=Cl+Ul else Cl=Cl+1 end
elseif Hl==39 then Dl[Kl]=tonumber(Dl[Rl]) Cl=Cl+1
elseif Hl==40 then Dl[Kl]=tostring(Dl[Rl]) Cl=Cl+1
elseif Hl==41 then Dl[Kl+3]=nil Cl=Cl+1
else Cl=Cl+1 end
end
return nil
end
local mp=Sl(1)
El(mp)
end
Il(ll,Ol)
