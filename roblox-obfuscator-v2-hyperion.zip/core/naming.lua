----------------------------------------------------------------
-- VARIABLE NAME GENERATOR
-- Produces obfuscated variable names that look like real identifiers
----------------------------------------------------------------
local M = {}

local _vc = 0
local _used = {}
local R = nil  -- set via M.init(R)

function M.init(reserved)
    R = reserved
end

function M.genName()
    local c = "IlOQDCGBASNMVEHKRFTYUPWXZJvwxyzcrnueiadfhjko"
    for _ = 1, 200000 do
        _vc = _vc + 1
        local n = ""; local b = _vc
        repeat
            n = n .. c:sub((b % #c) + 1, (b % #c) + 1)
            b = math.floor(b / #c)
        until b == 0
        if #n >= 2 and n:match("%l") and not R[n] and not _used[n] then
            _used[n] = true; return n
        end
    end
    local fb = "_v" .. 10000 + math.random(89999)
    _used[fb] = true; return fb
end

function M.reset()
    _vc = 0
    _used = {}
end

return M
