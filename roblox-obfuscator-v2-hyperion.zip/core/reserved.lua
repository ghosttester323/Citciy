----------------------------------------------------------------
-- RESERVED NAMES — Never rename these (Roblox globals, keywords, API)
----------------------------------------------------------------
local R = {}

-- Lua keywords
for _, w in ipairs({
    "and","break","do","else","elseif","end","false","for",
    "function","goto","if","in","local","nil","not","or",
    "repeat","return","then","true","until","while",
}) do R[w] = true end

-- Roblox / Lua globals
for _, w in ipairs({
    "game","workspace","script","print","warn","error","wait","spawn",
    "delay","tick","time","typeof","type","tostring","tonumber","pairs",
    "ipairs","next","select","unpack","pcall","xpcall","rawget","rawset",
    "rawequal","rawlen","setmetatable","getmetatable","require","loadstring",
    "coroutine","string","table","math","bit32","os","debug","Instance",
    "Vector3","Vector2","CFrame","Color3","BrickColor","Enum","UDim",
    "UDim2","TweenInfo","NumberSequence","ColorSequence","NumberRange",
    "Ray","Region3","Rect","PhysicalProperties","Random","task","utf8",
    "_G","shared","self",
}) do R[w] = true end

-- Roblox API members / common library functions
for _, w in ipairs({
    "Name","Value","Parent","Size","Position","Text","BackgroundColor3",
    "TextColor3","WalkSpeed","MaxHealth","Health","CharacterAdded",
    "PlayerAdded","UserId","PlayerGui","Character","Destroy","Clone",
    "FindFirstChild","IsA","WaitForChild","Connect","Disconnect",
    "GetService","GetPlayers","GetChildren","GetDescendants",
    "fromRGB","new","AnchorPoint","BackgroundTransparency",
    "BorderSizePixel","Font","TextSize","TextScaled","Visible","ZIndex",
    "Transparency","CanCollide","Material","Changed",
    "ChildAdded","ChildRemoved","Touched",
    "char","byte","sub","len","rep","find","format","match","gmatch",
    "gsub","upper","lower","reverse","concat",
    "insert","remove","sort","move",
    "abs","ceil","floor","max","min","sqrt","pow","sin","cos","tan",
    "asin","acos","atan","atan2","exp","log","random","randomseed",
    "clamp","sign","round","noise","huge","pi","fmod","deg","rad",
    "create","wrap","yield","resume","status","running",
}) do R[w] = true end

return R
