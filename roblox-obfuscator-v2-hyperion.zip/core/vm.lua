----------------------------------------------------------------
-- HYPERION VM v2.0 — 100% Custom Bytecode
-- 2-word instruction encoding with shuffled word order
-- Custom header format, shuffled opcodes, fake handlers, integrity
-- NO loadstring, NO bit32, NO XOR, NO ~ operator
-- Delta executor compatible (Lua 5.1, getfenv(0))
----------------------------------------------------------------
local M = {}

----------------------------------------------------------------
-- SECTION 1: TOKEN CONSTANTS & KEYWORDS
----------------------------------------------------------------
local TK_ID=1; TK_NUM=2; TK_STR=3; TK_KW=4; TK_OP=5
local TK_CMT=6; TK_WS=7; TK_NL=8; TK_EOF=9
local KW_MAP = {}
for _,w in ipairs({"and","break","do","else","elseif","end","false","for",
    "function","goto","if","in","local","nil","not","or",
    "repeat","return","then","true","until","while"}) do KW_MAP[w]=true end

----------------------------------------------------------------
-- SECTION 2: PARSER
----------------------------------------------------------------
local PREC = {
    ["or"]=1, ["and"]=2, ["<"]=3, [">"]=3, ["<="]=3, [">="]=3,
    ["~="]=3, ["=="]=3, [".."]=4, ["+"]=5, ["-"]=5,
    ["*"]=6, ["/"]=6, ["%"]=6, ["^"]=7, unary=8, postfix=9,
}

local function parser(toks)
    local pos = 1; local tn = #toks
    local function peek()
        while pos <= tn and (toks[pos].t == TK_WS or toks[pos].t == TK_NL or toks[pos].t == TK_CMT) do pos = pos + 1 end
        if pos <= tn then return toks[pos] else return {t=TK_EOF, v=""} end
    end
    local function advance() local t = peek(); if pos <= tn then pos = pos + 1 end; return t end
    local function check(v) return peek().v == v end
    local function match(v) if check(v) then advance(); return true end; return false end
    local function checkKw(v) local t = peek(); return t.t == TK_KW and t.v == v end
    local function matchKw(v) if checkKw(v) then advance(); return true end; return false end
    local expr, block, statement, parseFuncBody

    function tableConstructor()
        match("{"); local fields = {}
        while not check("}") do
            if check("[") then
                advance(); local key = expr(0); match("]"); match("=")
                fields[#fields+1] = {k=key, v=expr(0)}
            else
                local la = peek()
                if la.t == TK_ID then
                    local savePos = pos; advance()
                    if match("=") then
                        fields[#fields+1] = {k={type="string", value=la.v}, v=expr(0)}
                    else pos = savePos; fields[#fields+1] = {k=nil, v=expr(0)} end
                else fields[#fields+1] = {k=nil, v=expr(0)} end
            end
            if not match(",") and not match(";") then break end
        end
        match("}"); return {type="table", fields=fields}
    end

    function parseFuncBody()
        match("("); local params = {}; local hasVararg = false
        while not check(")") do
            if match("...") then hasVararg = true; break end
            params[#params+1] = advance().v; if not match(",") then break end
        end
        match(")"); local body = block(); matchKw("end")
        return params, body, hasVararg
    end

    function expr(minPrec)
        minPrec = minPrec or 0; local left; local t = peek()
        if t.t == TK_NUM then advance(); left = {type="number", value=t.nv or tonumber(t.v)}
        elseif t.t == TK_STR then advance(); left = {type="string", value=t.sv or t.v}
        elseif t.t == TK_KW and t.v == "true" then advance(); left = {type="bool", value=true}
        elseif t.t == TK_KW and t.v == "false" then advance(); left = {type="bool", value=false}
        elseif t.t == TK_KW and t.v == "nil" then advance(); left = {type="nil"}
        elseif t.t == TK_OP and t.v == "..." then advance(); left = {type="vararg"}
        elseif t.t == TK_OP and t.v == "-" then advance(); left = {type="unop", op="-", operand=expr(PREC.unary)}
        elseif t.t == TK_KW and t.v == "not" then advance(); left = {type="unop", op="not", operand=expr(PREC.unary)}
        elseif t.t == TK_OP and t.v == "#" then advance(); left = {type="unop", op="#", operand=expr(PREC.unary)}
        elseif t.t == TK_OP and t.v == "{" then left = tableConstructor()
        elseif t.t == TK_OP and t.v == "(" then advance(); left = expr(0); match(")")
        elseif t.t == TK_KW and t.v == "function" then
            advance(); match("("); local params = {}; local va = false
            while not check(")") do if match("...") then va = true; break end; params[#params+1] = advance().v; if not match(",") then break end end
            match(")"); local body = block(); matchKw("end")
            left = {type="function", params=params, body=body, vararg=va}
        elseif t.t == TK_ID then advance(); left = {type="name", name=t.v}
        else return nil end
        while true do
            t = peek()
            if t.t == TK_OP and t.v == "." then advance(); left = {type="dot", obj=left, name=advance().v}
            elseif t.t == TK_OP and t.v == "[" then advance(); local idx = expr(0); match("]"); left = {type="index", obj=left, key=idx}
            elseif t.t == TK_OP and t.v == "(" then
                advance(); local args = {}
                if not check(")") then args[#args+1] = expr(0); while match(",") do args[#args+1] = expr(0) end end
                match(")"); left = {type="call", func=left, args=args}
            elseif t.t == TK_OP and t.v == ":" then
                advance(); local method = advance().v; match("("); local args = {}
                if not check(")") then args[#args+1] = expr(0); while match(",") do args[#args+1] = expr(0) end end
                match(")"); left = {type="methodcall", obj=left, method=method, args=args}
            elseif t.t == TK_OP and t.v == "{" then left = {type="call", func=left, args={tableConstructor()}}
            elseif t.t == TK_STR then advance(); left = {type="call", func=left, args={{type="string", value=t.sv or t.v}}}
            else break end
        end
        while true do
            t = peek(); local tv = t.v; local p = PREC[tv]
            if not p or p < minPrec then break end; advance()
            if tv == "^" or tv == ".." then left = {type="binop", op=tv, left=left, right=expr(p)}
            else left = {type="binop", op=tv, left=left, right=expr(p + 1)} end
        end
        return left
    end

    function block()
        local stmts = {}
        while true do
            local t = peek()
            if t.t == TK_EOF then break end
            if t.t == TK_KW and (t.v == "end" or t.v == "else" or t.v == "elseif" or t.v == "until") then break end
            local s = statement(); if s then stmts[#stmts+1] = s else break end
        end
        return stmts
    end

    function statement()
        local t = peek()
        if t.t == TK_KW then
            if t.v == "local" then
                matchKw("local")
                if checkKw("function") then
                    matchKw("function"); local name = advance().v; local params, body, va = parseFuncBody()
                    return {type="localfunc", name=name, params=params, body=body, vararg=va}
                end
                local names = {advance().v}; while match(",") do names[#names+1] = advance().v end
                local inits = {}
                if match("=") then inits[#inits+1] = expr(0); while match(",") do inits[#inits+1] = expr(0) end end
                return {type="local", names=names, inits=inits}
            elseif t.v == "if" then
                matchKw("if"); local cond = expr(0); matchKw("then"); local body = block()
                local elseifs = {}
                while matchKw("elseif") do local ec = expr(0); matchKw("then"); local eb = block(); elseifs[#elseifs+1] = {cond=ec, body=eb} end
                local elsebody = {}; if matchKw("else") then elsebody = block() end; matchKw("end")
                return {type="if", cond=cond, body=body, elseifs=elseifs, elsebody=elsebody}
            elseif t.v == "while" then
                matchKw("while"); local cond = expr(0); matchKw("do"); local body = block(); matchKw("end")
                return {type="while", cond=cond, body=body}
            elseif t.v == "for" then
                matchKw("for"); local var = advance().v
                if match("=") then
                    local from = expr(0); match(","); local to = expr(0); local step = nil
                    if match(",") then step = expr(0) end
                    matchKw("do"); local body = block(); matchKw("end")
                    return {type="fornum", var=var, from=from, to=to, step=step, body=body}
                else
                    local vars = {var}; while match(",") do vars[#vars+1] = advance().v end
                    matchKw("in"); local iters = {expr(0)}; while match(",") do iters[#iters+1] = expr(0) end
                    matchKw("do"); local body = block(); matchKw("end")
                    return {type="forin", vars=vars, iters=iters, body=body}
                end
            elseif t.v == "repeat" then
                matchKw("repeat"); local body = block(); matchKw("until"); local cond = expr(0)
                return {type="repeat", body=body, cond=cond}
            elseif t.v == "return" then
                matchKw("return"); local values = {}
                if not checkKw("end") and not checkKw("else") and not checkKw("elseif") and not checkKw("until") and peek().t ~= TK_EOF then
                    values[#values+1] = expr(0); while match(",") do values[#values+1] = expr(0) end
                end
                return {type="return", values=values}
            elseif t.v == "break" then advance(); return {type="break"}
            elseif t.v == "function" then
                matchKw("function"); local name = advance().v; local params, body, va = parseFuncBody()
                return {type="funcdecl", name=name, params=params, body=body, vararg=va}
            elseif t.v == "do" then advance(); local b = block(); matchKw("end"); return {type="block", stmts=b}
            end
        end
        if t.t == TK_ID or (t.t == TK_OP and t.v == "(") then
            local e = expr(0); if not e then return nil end
            if check("=") then
                advance(); local targets = {e}; while match(",") do targets[#targets+1] = expr(0) end
                local values = {expr(0)}; while match(",") do values[#values+1] = expr(0) end
                return {type="assign", targets=targets, values=values}
            end
            return {type="exprstmt", expr=e}
        end
        return nil
    end
    return block()
end

----------------------------------------------------------------
-- SECTION 3: COMPILER
-- 2-word instruction: wordA=(op:10|ra:8|fb:14), wordB=(fc:16|jump:16)
-- wordFlip randomizes order of the 2 words per build
----------------------------------------------------------------
local NUM_REAL = 43; local NUM_FAKE = 5
local OP_NOP=0; OP_LOADK=1; OP_LOADNIL=2; OP_LOADBOOL=3; OP_MOVE=4
local OP_NEG=5; OP_ADD=6; OP_SUB=7; OP_MUL=8; OP_DIV=9; OP_MOD=10
local OP_POW=11; OP_EQ=12; OP_LT=13; OP_LE=14; OP_NEQ=15; OP_NOT=16
local OP_AND=17; OP_OR=18; OP_LEN=19; OP_CONCAT=20
local OP_JMP=21; OP_JZ=22; OP_JNZ=23
local OP_FORPREP=24; OP_FORLOOP=25
local OP_CALL=26; OP_RETURN=27
local OP_GETGLOBAL=28; OP_SETGLOBAL=29
local OP_GETTABLE=30; OP_SETTABLE=31; OP_GETINDEX=32; OP_SETINDEX=33
local OP_NEWTABLE=34; OP_SETLIST=35; OP_CLOSURE=36
local OP_TYPEOF=37; OP_PAIRSLOOP=38; OP_TONUMBER=39; OP_TOSTRING=40
local OP_PAIRSPREP=41; OP_PAIRSCALL=42

local function KB(x) return 256 + x end

local function genConfig(rng)
    local total = NUM_REAL + NUM_FAKE
    local slots = {}
    for i = 0, total - 1 do slots[i+1] = i end
    for i = total, 2, -1 do local j = rng(1, i); slots[i], slots[j] = slots[j], slots[i] end
    local opMap = {}
    for realOp = 0, NUM_REAL - 1 do opMap[realOp] = slots[realOp+1] end
    local fakes = {}
    for i = NUM_REAL + 1, total do fakes[#fakes+1] = slots[i] end
    local wordFlip = rng(1, 2) == 2
    return { opMap = opMap, fakes = fakes, wordFlip = wordFlip }
end

local function newCompiler(cfg)
    local self = {
        consts = {}, constsMap = {}, instrs = {}, subs = {},
        regTop = 8, scopeStack = {{vars={}}}, regFloor = 8, cfg = cfg,
    }
    function self.getMaxNamedReg()
        local maxR = 7
        for si = #self.scopeStack, 1, -1 do
            for name, reg in pairs(self.scopeStack[si].vars) do if reg > maxR then maxR = reg end end
        end
        return maxR
    end
    function self.recycleRegs() self.regTop = math.max(self.getMaxNamedReg() + 1, self.regFloor) end
    function self.addConst(v)
        local key
        if type(v) == "number" then key = "N:" .. v
        elseif type(v) == "string" then key = "S:" .. v
        elseif type(v) == "boolean" then key = "B:" .. tostring(v)
        else key = "X:nil" end
        if self.constsMap[key] then return self.constsMap[key] end
        local idx = #self.consts + 1; self.consts[idx] = v; self.constsMap[key] = idx; return idx
    end
    function self.encode(op, a, b, c)
        local sop = cfg.opMap[op] or 0
        local wordA = (sop << 22) | ((a & 0xFF) << 14) | (b & 0x3FFF)
        local wordB = (c & 0xFFFF)
        if cfg.wordFlip then return wordB, wordA else return wordA, wordB end
    end
    function self.emit(op, a, b, c)
        a = a or 0; b = b or 0; c = c or 0
        local wA, wB = self.encode(op, a, b, c)
        self.instrs[#self.instrs+1] = {wA, wB, op = op, ra = a}
        return #self.instrs
    end
    function self.patchJump(idx, off)
        local ins = self.instrs[idx]
        if not ins then return end
        local v = off % 0x10000
        if v < 0 then v = v + 0x10000 end
        local origA = ins.ra or 0
        local wA, wB = self.encode(ins.op, origA, 0, v)
        ins[1] = wA; ins[2] = wB
    end
    function self.allocReg(name)
        local r = self.regTop; self.regTop = self.regTop + 1
        if name then self.scopeStack[#self.scopeStack].vars[name] = r end
        return r
    end
    function self.getReg(name)
        for i = #self.scopeStack, 1, -1 do
            if self.scopeStack[i].vars[name] then return self.scopeStack[i].vars[name] end
        end
        return nil
    end
    function self.pushScope() self.scopeStack[#self.scopeStack+1] = {vars={}} end
    function self.popScope() table.remove(self.scopeStack) end

    function self.compileExpr(e)
        if not e then return 0 end
        if e.type == "number" then local r = self.allocReg(); self.emit(OP_LOADK, r, KB(self.addConst(e.value)), 0); return r
        elseif e.type == "string" then local r = self.allocReg(); self.emit(OP_LOADK, r, KB(self.addConst(e.value)), 0); return r
        elseif e.type == "bool" then local r = self.allocReg(); self.emit(OP_LOADBOOL, r, e.value and 1 or 0, 0); return r
        elseif e.type == "nil" then local r = self.allocReg(); self.emit(OP_LOADNIL, r, 0, 0); return r
        elseif e.type == "name" then
            local reg = self.getReg(e.name)
            if reg then local r = self.allocReg(); self.emit(OP_MOVE, r, reg, 0); return r
            else local r = self.allocReg(); self.emit(OP_GETGLOBAL, r, KB(self.addConst(e.name)), 0); return r end
        elseif e.type == "binop" then
            local op = e.op
            if op == ">" then
                local lr = self.compileExpr(e.left); local rr = self.compileExpr(e.right)
                local res = self.allocReg(); self.emit(OP_LT, res, rr, lr); return res
            elseif op == ">=" then
                local lr = self.compileExpr(e.left); local rr = self.compileExpr(e.right)
                local res = self.allocReg(); self.emit(OP_LE, res, rr, lr); return res
            elseif op == "and" then
                local lr = self.compileExpr(e.left)
                local jzIdx = self.emit(OP_JZ, lr, 0, 0)
                local res = self.allocReg(); self.emit(OP_MOVE, res, lr, 0)
                local rr = self.compileExpr(e.right)
                self.emit(OP_MOVE, res, rr, 0)
                self.patchJump(jzIdx, #self.instrs - jzIdx - 2); return res
            elseif op == "or" then
                local lr = self.compileExpr(e.left)
                local res = self.allocReg(); self.emit(OP_MOVE, res, lr, 0)
                local jnzIdx = self.emit(OP_JNZ, lr, 0, 0)
                local rr = self.compileExpr(e.right)
                self.emit(OP_MOVE, res, rr, 0)
                self.patchJump(jnzIdx, #self.instrs - jnzIdx - 2); return res
            end
            local opMap = {["+"]=OP_ADD,["-"]=OP_SUB,["*"]=OP_MUL,["/"]=OP_DIV,
                ["%"]=OP_MOD,["^"]=OP_POW,[".."]=OP_CONCAT,
                ["=="]=OP_EQ,["~="]=OP_NEQ,["<"]=OP_LT,["<="]=OP_LE}
            local opCode = opMap[op]
            if not opCode then return self.allocReg() end
            local lr = self.compileExpr(e.left); local rr = self.compileExpr(e.right)
            local res = self.allocReg(); self.emit(opCode, res, lr, rr); return res
        elseif e.type == "unop" then
            local operand = self.compileExpr(e.operand); local res = self.allocReg()
            if e.op == "-" then self.emit(OP_NEG, res, operand, 0)
            elseif e.op == "not" then self.emit(OP_NOT, res, operand, 0)
            elseif e.op == "#" then self.emit(OP_LEN, res, operand, 0) end
            return res
        elseif e.type == "dot" then
            local objR = self.compileExpr(e.obj); local res = self.allocReg()
            self.emit(OP_GETINDEX, res, objR, KB(self.addConst(e.name))); return res
        elseif e.type == "index" then
            local objR = self.compileExpr(e.obj); local keyR = self.compileExpr(e.key); local res = self.allocReg()
            self.emit(OP_GETTABLE, res, objR, keyR); return res
        elseif e.type == "call" then
            local funcR = self.compileExpr(e.func); local argRegs = {}
            for _, a in ipairs(e.args) do argRegs[#argRegs+1] = self.compileExpr(a) end
            for i, argReg in ipairs(argRegs) do if argReg ~= funcR + i then self.emit(OP_MOVE, funcR + i, argReg, 0) end end
            self.emit(OP_CALL, funcR, #e.args, 1); return funcR
        elseif e.type == "methodcall" then
            local objR = self.compileExpr(e.obj); local methR = self.allocReg()
            self.emit(OP_GETINDEX, methR, objR, KB(self.addConst(e.method)))
            self.emit(OP_MOVE, methR + 1, objR, 0)
            local argRegs = {}
            for _, a in ipairs(e.args) do argRegs[#argRegs+1] = self.compileExpr(a) end
            for i, argReg in ipairs(argRegs) do self.emit(OP_MOVE, methR + 1 + i, argReg, 0) end
            self.emit(OP_CALL, methR, #e.args + 1, 1); return methR
        elseif e.type == "table" then
            local tblReg = self.allocReg(); self.emit(OP_NEWTABLE, tblReg, 0, 0)
            for i, field in ipairs(e.fields) do
                if field.k then
                    local kR = self.compileExpr(field.k); local vR = self.compileExpr(field.v)
                    self.emit(OP_SETTABLE, tblReg, kR, vR)
                else local vR = self.compileExpr(field.v); self.emit(OP_SETINDEX, tblReg, KB(self.addConst(i)), vR) end
            end
            return tblReg
        elseif e.type == "function" then
            local subReg = self.allocReg()
            local sub = newCompiler(cfg)
            for si = #self.scopeStack, 1, -1 do
                for name, reg in pairs(self.scopeStack[si].vars) do
                    if not sub.scopeStack[#sub.scopeStack].vars[name] then sub.scopeStack[#sub.scopeStack].vars[name] = reg end
                end
            end
            local maxPV = 7
            for si = #self.scopeStack, 1, -1 do
                for name, reg in pairs(self.scopeStack[si].vars) do if reg > maxPV then maxPV = reg end end
            end
            sub.regTop = math.max(sub.regTop, math.min(maxPV + 1, 128))
            local pb = sub.regTop - 1
            for _, p in ipairs(e.params) do sub.allocReg(p) end
            sub.compileStmts(e.body); sub.emit(OP_RETURN, 0, 0, 0)
            self.subs[#self.subs+1] = sub
            self.emit(OP_CLOSURE, subReg, KB(self.addConst(#self.subs)), pb); return subReg
        else
            local r = self.allocReg(); self.emit(OP_LOADNIL, r, 0, 0); return r
        end
    end

    function self.compileStmts(stmts)
        for _, s in ipairs(stmts) do self.compileStmt(s); self.recycleRegs() end
    end

    function self.compileStmt(s)
        if not s then return end
        if s.type == "local" then
            local regs = {}
            for _, name in ipairs(s.names) do regs[#regs+1] = self.allocReg(name) end
            for i, init in ipairs(s.inits) do local valR = self.compileExpr(init); self.emit(OP_MOVE, regs[i], valR, 0) end
            for i = #s.inits + 1, #s.names do self.emit(OP_LOADNIL, regs[i], 0, 0) end
        elseif s.type == "localfunc" then
            local fnReg = self.allocReg(s.name)
            local sub = newCompiler(cfg)
            for si = #self.scopeStack, 1, -1 do
                for name, reg in pairs(self.scopeStack[si].vars) do
                    if not sub.scopeStack[#sub.scopeStack].vars[name] then sub.scopeStack[#sub.scopeStack].vars[name] = reg end
                end
            end
            local maxPV = 7
            for si = #self.scopeStack, 1, -1 do
                for name, reg in pairs(self.scopeStack[si].vars) do if reg > maxPV then maxPV = reg end end
            end
            sub.regTop = math.max(sub.regTop, math.min(maxPV + 1, 128))
            local pb = sub.regTop - 1
            for _, p in ipairs(s.params) do sub.allocReg(p) end
            sub.compileStmts(s.body); sub.emit(OP_RETURN, 0, 0, 0)
            self.subs[#self.subs+1] = sub
            self.emit(OP_CLOSURE, fnReg, KB(self.addConst(#self.subs)), pb)
        elseif s.type == "funcdecl" then
            local reg = self.getReg(s.name)
            if reg then
                local sub = newCompiler(cfg)
                for si = #self.scopeStack, 1, -1 do
                    for name, reg2 in pairs(self.scopeStack[si].vars) do
                        if not sub.scopeStack[#sub.scopeStack].vars[name] then sub.scopeStack[#sub.scopeStack].vars[name] = reg2 end
                    end
                end
                local maxPV = 7
                for si = #self.scopeStack, 1, -1 do
                    for name, reg2 in pairs(self.scopeStack[si].vars) do if reg2 > maxPV then maxPV = reg2 end end
                end
                sub.regTop = math.max(sub.regTop, math.min(maxPV + 1, 128))
                local pb = sub.regTop - 1
                for _, p in ipairs(s.params) do sub.allocReg(p) end
                sub.compileStmts(s.body); sub.emit(OP_RETURN, 0, 0, 0)
                self.subs[#self.subs+1] = sub
                self.emit(OP_CLOSURE, reg, KB(self.addConst(#self.subs)), pb)
            end
        elseif s.type == "assign" then
            for i, target in ipairs(s.targets) do
                local valR = self.compileExpr(s.values[i] or {type="nil"})
                if target.type == "name" then
                    local reg = self.getReg(target.name)
                    if reg then self.emit(OP_MOVE, reg, valR, 0)
                    else self.emit(OP_SETGLOBAL, valR, KB(self.addConst(target.name)), 0) end
                elseif target.type == "dot" then
                    local objR = self.compileExpr(target.obj)
                    self.emit(OP_SETINDEX, objR, KB(self.addConst(target.name)), valR)
                elseif target.type == "index" then
                    local objR = self.compileExpr(target.obj); local keyR = self.compileExpr(target.key)
                    self.emit(OP_SETTABLE, objR, keyR, valR)
                end
            end
        elseif s.type == "if" then
            local condR = self.compileExpr(s.cond)
            local skipBody = self.emit(OP_JZ, condR, 0, 0)
            self.compileStmts(s.body)
            local jumpToEnds = {}
            if #s.elseifs > 0 or #s.elsebody > 0 then jumpToEnds[#jumpToEnds+1] = self.emit(OP_JMP, 0, 0, 0) end
            self.patchJump(skipBody, #self.instrs - skipBody)
            for _, ei in ipairs(s.elseifs) do
                local ecR = self.compileExpr(ei.cond); local skipEI = self.emit(OP_JZ, ecR, 0, 0)
                self.compileStmts(ei.body); jumpToEnds[#jumpToEnds+1] = self.emit(OP_JMP, 0, 0, 0)
                self.patchJump(skipEI, #self.instrs - skipEI)
            end
            self.compileStmts(s.elsebody)
            for _, je in ipairs(jumpToEnds) do self.patchJump(je, #self.instrs - je) end
        elseif s.type == "while" then
            local loopStart = #self.instrs + 1
            local condR = self.compileExpr(s.cond); local exitJump = self.emit(OP_JZ, condR, 0, 0)
            self.compileStmts(s.body)
            local backJmp = self.emit(OP_JMP, 0, 0, 0)
            self.patchJump(backJmp, loopStart - backJmp - 1)
            self.patchJump(exitJump, #self.instrs - exitJump)
        elseif s.type == "fornum" then
            local loopReg = self.allocReg(s.var); local limitReg = self.allocReg(); local stepReg = self.allocReg()
            local savedFloor = self.regFloor; self.regFloor = math.max(self.regFloor, self.regTop)
            local fromR = self.compileExpr(s.from); local toR = self.compileExpr(s.to)
            self.emit(OP_MOVE, loopReg, fromR, 0); self.emit(OP_MOVE, limitReg, toR, 0)
            if s.step then local stepR = self.compileExpr(s.step); self.emit(OP_MOVE, stepReg, stepR, 0)
            else self.emit(OP_LOADK, stepReg, KB(self.addConst(1)), 0) end
            local prepJmp = self.emit(OP_FORPREP, loopReg, 0, 0)
            local loopStart = #self.instrs + 1
            self.compileStmts(s.body)
            local loopJmp = self.emit(OP_FORLOOP, loopReg, 0, 0)
            self.patchJump(loopJmp, loopStart - loopJmp - 1)
            self.patchJump(prepJmp, #self.instrs - prepJmp - 1)
            self.regFloor = savedFloor
        elseif s.type == "forin" then
            local iterRegs = {self.allocReg(), self.allocReg(), self.allocReg(), self.allocReg(), self.allocReg()}
            for _, var in ipairs(s.vars) do self.allocReg(var) end
            local savedFloor = self.regFloor; self.regFloor = math.max(self.regFloor, self.regTop)
            local iter = s.iters[1]
            if iter.type == "call" then
                local funcR = self.compileExpr(iter.func); local argRegs = {}
                for _, a in ipairs(iter.args) do argRegs[#argRegs+1] = self.compileExpr(a) end
                for i, argReg in ipairs(argRegs) do self.emit(OP_MOVE, funcR + i, argReg, 0) end
                self.emit(OP_PAIRSCALL, funcR, #iter.args, iterRegs[1])
            else
                local iR = self.compileExpr(iter)
                self.emit(OP_MOVE, iterRegs[1], iR, 0); self.emit(OP_LOADNIL, iterRegs[2], 0)
            end
            self.emit(OP_LOADNIL, iterRegs[3], 0, 0)
            self.emit(OP_PAIRSPREP, iterRegs[1], 0, 0)
            local loopStart = #self.instrs + 1
            local loopJmp = self.emit(OP_PAIRSLOOP, iterRegs[1], 0, 0)
            for j, var in ipairs(s.vars) do
                local varReg = self.getReg(var)
                if varReg then self.emit(OP_MOVE, varReg, iterRegs[j+3], 0) end
            end
            self.compileStmts(s.body)
            local backJmp = self.emit(OP_JMP, 0, 0, 0)
            self.patchJump(backJmp, loopStart - backJmp - 1)
            self.patchJump(loopJmp, #self.instrs - loopJmp)
            self.regFloor = savedFloor
        elseif s.type == "repeat" then
            local loopStart = #self.instrs + 1
            self.compileStmts(s.body)
            local condR = self.compileExpr(s.cond)
            local exitJmp = self.emit(OP_JNZ, condR, 0, 0)
            local backJmp = self.emit(OP_JMP, 0, 0, 0)
            self.patchJump(backJmp, loopStart - backJmp - 1)
            self.patchJump(exitJmp, #self.instrs - exitJmp)
        elseif s.type == "return" then
            if #s.values > 0 then local retReg = self.compileExpr(s.values[1]); self.emit(OP_RETURN, retReg, 1, 0)
            else self.emit(OP_RETURN, 0, 0, 0) end
        elseif s.type == "break" then self.emit(OP_JMP, 0, 0x1FF, 0)
        elseif s.type == "exprstmt" then self.compileExpr(s.expr)
        elseif s.type == "block" then self.compileStmts(s.stmts)
        end
    end
    return self
end

----------------------------------------------------------------
-- SECTION 4: SERIALIZER
----------------------------------------------------------------
local function serialize(comp, salt)
    local function ser(c)
        local d = {}
        d[#d+1] = #c.consts; d[#d+1] = #c.instrs; d[#d+1] = #c.subs
        for _, v in ipairs(c.consts) do
            if type(v) == "number" then d[#d+1] = 0; d[#d+1] = v
            elseif type(v) == "string" then d[#d+1] = 1
                for i = 1, #v do d[#d+1] = (string.byte(v, i) + salt) % 256 end
                d[#d+1] = (0 + salt) % 256
            elseif type(v) == "boolean" then d[#d+1] = 2; d[#d+1] = v and 1 or 0
            else d[#d+1] = 3; d[#d+1] = 0 end
        end
        for _, ins in ipairs(c.instrs) do d[#d+1] = ins[1]; d[#d+1] = ins[2] end
        for _, sub in ipairs(c.subs) do
            local sd = ser(sub); d[#d+1] = #sd
            for _, v in ipairs(sd) do d[#d+1] = v end
        end
        return d
    end
    local data = ser(comp)
    local checksum = 0
    for i = 1, #data do checksum = (checksum * 31 + data[i]) % 2147483647 end
    return data, checksum
end

----------------------------------------------------------------
-- SECTION 5: RUNTIME GENERATOR
----------------------------------------------------------------
local function generateRuntime(env, data, cfg, salt, checksum)
    local genName = env.naming.genName
    local n = function() return genName() end
    local vmFn=n(); local dat=n(); local r=n(); local pc=n(); local cst=n()
    local ix=n(); local ex=n(); local op=n(); local ra=n(); local fb=n()
    local fc=n(); local bv=n(); local cv=n(); local sj=n(); local pr=n()
    local rp=n(); local sl=n(); local wf=n()
    local L = {}
    local function emit(...) L[#L+1] = table.concat({...}) end

    local dataStr = table.concat(data, ",")
    emit("local ", dat, "={", dataStr, "}")
    emit("local unpack=unpack or table.unpack")
    emit("local function ", vmFn, "(", dat, ")")
    emit("local _ck=", checksum)
    emit("local _cs=0 for _i=1,#", dat, " do _cs=(_cs*31+", dat, "[_i])%2147483647 end")
    emit("if _cs~=_ck then while true do end end")
    emit("local _E=(type(getfenv)=='function' and getfenv(0)) or _G or {}")
    emit("local ", sl, "=", salt % 256)
    emit("local ", wf, "=", cfg.wordFlip and 1 or 0)

    emit("local function ", rp, "(off)")
    emit("local nc=", dat, "[off] off=off+1 local ni=", dat, "[off] off=off+1 local ns=", dat, "[off] off=off+1")
    emit("local ct={}")
    emit("for i=1,nc do local t=", dat, "[off] off=off+1")
    emit("if t==0 then ct[i]=", dat, "[off] off=off+1")
    emit("elseif t==1 then local s='' while true do local v=", dat, "[off] off=off+1 if v==", sl, " then break end s=s..string.char((v-", sl, ")%256) end ct[i]=s")
    emit("elseif t==2 then ct[i]=(", dat, "[off]==1) off=off+1")
    emit("else off=off+1 end end")
    emit("local is={}")
    emit("for i=1,ni*2 do is[i]=", dat, "[off] off=off+1 end")
    emit("local sb={}")
    emit("for i=1,ns do local sz=", dat, "[off] off=off+1 sb[i]=", rp, "(off) off=sb[i].off end")
    emit("return {ct=ct,is=is,sb=sb,ni=ni,off=off}")
    emit("end")

    emit("local function ", ex, "(", pr, ",parentR)")
    emit("local ", r, "={}")
    emit("for i=0,511 do ", r, "[i]=nil end")
    emit(r, "[1]=true ", r, "[2]=false")
    emit("if parentR then for i=0,511 do ", r, "[i]=parentR[i] end end")
    emit("local ", cst, "=", pr, ".ct local ", ix, "=", pr, ".is local ", pc, "=1")
    emit("while ", pc, "<=", pr, ".ni do")
    emit("local bi=((", pc, "-1)*2)+1")
    emit("local w0=", ix, "[bi] local w1=", ix, "[bi+1]")
    emit("local a0,b0")
    emit("if ", wf, "==1 then a0=w1 b0=w0 else a0=w0 b0=w1 end")
    emit("local ", op, "=math.floor(a0/4194304)%1024")
    emit("local ", ra, "=math.floor(a0/16384)%256")
    emit("local ", fb, "=a0%16384")
    emit("local ", fc, "=b0%65536")
    emit("local ", sj, "=", fc)
    emit("if ", sj, ">=32768 then ", sj, "=", sj, "-65536 end")
    emit("local ", bv, "=", fb, ">=256 and ", cst, "[", fb, "-256] or ", r, "[", fb, "]")
    emit("local ", cv, "=", fc, ">=256 and ", cst, "[", fc, "-256] or ", r, "[", fc, "]")

    local RB = r .. "[" .. fb .. "]"
    local RC = r .. "[" .. fc .. "]"
    local RRA = r .. "[" .. ra .. "]"
    local sm = cfg.opMap

    emit("if false then end")
    emit("if ", op, "==", sm[OP_NOP], " then ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_LOADK], " then ", RRA, "=", bv, " ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_LOADNIL], " then ", RRA, "=nil ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_LOADBOOL], " then ", RRA, "=(", fb, "==1) ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_MOVE], " then ", RRA, "=", RB, " ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_NEG], " then ", RRA, "=-", RB, " ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_ADD], " then ", RRA, "=", RB, "+", cv, " ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_SUB], " then ", RRA, "=", RB, "-", cv, " ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_MUL], " then ", RRA, "=", RB, "*", cv, " ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_DIV], " then ", RRA, "=", RB, "/", cv, " ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_MOD], " then ", RRA, "=", RB, "%", cv, " ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_POW], " then ", RRA, "=", RB, "^", cv, " ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_EQ], " then ", RRA, "=(", RB, "==", cv, ") ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_LT], " then ", RRA, "=(", RB, "<", cv, ") ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_LE], " then ", RRA, "=(", RB, "<=", cv, ") ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_NEQ], " then ", RRA, "=(", RB, "~=", cv, ") ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_NOT], " then ", RRA, "=(not ", RB, ") ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_AND], " then ", RRA, "=", RB, " and ", cv, " ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_OR], " then ", RRA, "=", RB, " or ", cv, " ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_LEN], " then ", RRA, "=#", RB, " ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_CONCAT], " then ", RRA, "=tostring(", RB, ")..tostring(", cv, ") ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_JMP], " then ", pc, "=", pc, "+1+", sj)
    emit("elseif ", op, "==", sm[OP_JZ], " then if not ", RRA, " then ", pc, "=", pc, "+1+", sj, " else ", pc, "=", pc, "+1 end")
    emit("elseif ", op, "==", sm[OP_JNZ], " then if ", RRA, " then ", pc, "=", pc, "+1+", sj, " else ", pc, "=", pc, "+1 end")
    emit("elseif ", op, "==", sm[OP_FORPREP], " then if(", RRA, "-", r, "[", ra, "+2])>", r, "[", ra, "+1] then ", pc, "=", pc, "+1+", sj, " else ", pc, "=", pc, "+1 end")
    emit("elseif ", op, "==", sm[OP_FORLOOP], " then ", RRA, "=", RRA, "+", r, "[", ra, "+2] if(", r, "[", ra, "+2]>0 and ", RRA, "<=", r, "[", ra, "+1]) or(", r, "[", ra, "+2]<=0 and ", RRA, ">=", r, "[", ra, "+1]) then ", pc, "=", pc, "+", sj, " else ", pc, "=", pc, "+1 end")
    emit("elseif ", op, "==", sm[OP_CALL], " then local ag={} for ai=1,", fb, " do ag[ai]=", r, "[", ra, "+ai] end local rt=", RRA, "(unpack(ag)) ", RRA, "=rt ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_RETURN], " then return ", RRA)
    emit("elseif ", op, "==", sm[OP_GETGLOBAL], " then ", RRA, "=_E[", bv, "] ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_SETGLOBAL], " then _E[", bv, "]=", RRA, " ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_GETTABLE], " then ", RRA, "=", RB, "[", cv, "] ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_SETTABLE], " then ", RRA, "[", bv, "]=", cv, " ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_GETINDEX], " then ", RRA, "=", RB, "[", cv, "] ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_SETINDEX], " then ", RRA, "[", bv, "]=", r, "[", fc, "] ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_NEWTABLE], " then ", RRA, "={} ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_SETLIST], " then ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_CLOSURE], " then local sp=", pr, ".sb[", bv, "] local cr={} for ci=0,511 do cr[ci]=", r, "[ci] end ", RRA, "=function(...) local nr={} for ni=0,511 do nr[ni]=cr[ni] end local ca={...} for ai=1,#ca do nr[", fc, "+ai]=ca[ai] end return ", ex, "(sp,nr) end cr[", ra, "]=", RRA, " ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_TYPEOF], " then ", RRA, "=type(", RB, ") ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_PAIRSLOOP], " then local v1,v2=", r, "[", ra, "](", r, "[", ra, "+1],", r, "[", ra, "+2]) if v1==nil then ", pc, "=", pc, "+1+", sj, " else ", r, "[", ra, "+3]=v1 ", r, "[", ra, "+4]=v2 ", r, "[", ra, "+2]=v1 ", pc, "=", pc, "+1 end")
    emit("elseif ", op, "==", sm[OP_TONUMBER], " then ", RRA, "=tonumber(", RB, ") ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_TOSTRING], " then ", RRA, "=tostring(", RB, ") ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_PAIRSPREP], " then ", r, "[", ra, "+2]=nil ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", sm[OP_PAIRSCALL], " then local ag={} for ai=1,", fb, " do ag[ai]=", r, "[", ra, "+ai] end local r1,r2,r3=", RRA, "(unpack(ag)) ", r, "[", fc, "]=r1 ", r, "[", fc, "+1]=r2 ", r, "[", fc, "+2]=r3 ", pc, "=", pc, "+1")

    local fo = cfg.fakes
    emit("elseif ", op, "==", fo[1], " then ", RRA, "=nil ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", fo[2], " then ", RB, "=nil ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", fo[3], " then local _t={} ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", fo[4], " then ", r, "[", fb, "]=", RC, " ", pc, "=", pc, "+1")
    emit("elseif ", op, "==", fo[5], " then ", RRA, "=", RB, " ", pc, "=", pc, "+1")

    emit("else ", pc, "=", pc, "+1 end")
    emit("end")
    emit("return nil")
    emit("end")
    emit("local mp=", rp, "(1)")
    emit("if mp then ", ex, "(mp) end")
    emit("end")
    return table.concat(L, "\n") .. "\n" .. vmFn .. "(" .. dat .. ")\n"
end

----------------------------------------------------------------
-- SECTION 6: ENTRY POINT
----------------------------------------------------------------
function M.process(source, env)
    local rng = env.prng.rng
    local toks = env.tokenizer.tokenize(source)
    local ast = parser(toks)
    local salt = rng(1, 255)
    local cfg = genConfig(rng)
    local comp = newCompiler(cfg)
    comp.compileStmts(ast)
    comp.emit(OP_RETURN, 0, 0, 0)
    local data, checksum = serialize(comp, salt)
    return generateRuntime(env, data, cfg, salt, checksum)
end

return M
