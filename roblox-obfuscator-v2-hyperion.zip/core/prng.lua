----------------------------------------------------------------
-- PRNG — Pseudo-Random Number Generator
-- Seeded LCG for reproducible obfuscation
----------------------------------------------------------------
local _seed = 0

local M = {}

function M.setseed(s)
    _seed = s or os.time()
end

function M.rng(a, b)
    _seed = (_seed * 1103515245 + 12345) % 2147483648
    return a + (_seed % (b - a + 1))
end

function M.pick(t)
    return t[M.rng(1, #t)]
end

return M
