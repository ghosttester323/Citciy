----------------------------------------------------------------
-- UTILS — Shared helper functions for passes
----------------------------------------------------------------
local M = {}

--- Check if a line is safe to inject dead code after
--- (won't break control flow or declarations)
function M.isSafeLine(line)
    local t=line:match("^%s*(.-)%s*$")
    if #t==0 then return false end
    if t:match("^return[%s%(]") or t=="return" then return false end
    if t:match("^break$") or t:match("^break[%s;]") then return false end
    local w=t:match("(%w+)$")
    if w and (w=="then" or w=="do" or w=="else" or w=="elseif"
        or w=="end" or w=="function" or w=="local" or w=="repeat"
        or w=="and" or w=="or" or w=="not" or w=="in"
        or w=="return" or w=="break") then return false end
    local c=t:sub(-1,-1)
    if c=="," or c=="+" or c=="-" or c=="*" or c=="/"
        or c=="(" or c=="{" or c=="[" or c=="=" or c=="<" or c==">" or c=="." then return false end
    return true
end

--- Split source into lines
function M.splitLines(source)
    local lines = {}
    for line in source:gmatch("[^\n]+") do lines[#lines+1] = line end
    return lines
end

--- Join lines with newlines
function M.joinLines(lines)
    return table.concat(lines, "\n")
end

--- Generate an opaque predicate (always-true expression)
function M.opaque(rng)
    local p=rng(1,6); local a,b=rng(100,9999),rng(100,9999)
    if p==1 then return "(not false)"
    elseif p==2 then return "("..(a+b-a).."=="..b..")"
    elseif p==3 then return "(type("..rng(10,999)..")=='number')"
    elseif p==4 then return "(("..a.."+"..b..")^0==1)"
    elseif p==5 then return "("..(a*1).."=="..a..")"
    else return "(not not true)" end
end

return M
