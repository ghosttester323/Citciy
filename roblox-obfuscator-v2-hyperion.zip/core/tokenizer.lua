----------------------------------------------------------------
-- TOKENIZER — Hand-written Lua lexer
-- Token types, keyword map, tokenize(), toSource(), formatOutput()
----------------------------------------------------------------
local M = {}

-- Token types
M.TK_ID  = 1
M.TK_NUM = 2
M.TK_STR = 3
M.TK_KW  = 4
M.TK_OP  = 5
M.TK_CMT = 6
M.TK_WS  = 7
M.TK_NL  = 8
M.TK_EOF = 9

local TK_ID=M.TK_ID; TK_NUM=M.TK_NUM; TK_STR=M.TK_STR
local TK_KW=M.TK_KW; TK_OP=M.TK_OP; TK_CMT=M.TK_CMT
local TK_WS=M.TK_WS; TK_NL=M.TK_NL; TK_EOF=M.TK_EOF

-- Keyword lookup table
local KW = {}
for _, w in ipairs({
    "and","break","do","else","elseif","end","false","for",
    "function","goto","if","in","local","nil","not","or",
    "repeat","return","then","true","until","while",
}) do KW[w] = true end

function M.tokenize(src)
    local toks = {}
    local i = 1; local n = #src
    local function pk(c) return src:sub(i, i + (c or 1) - 1) end
    local function adv(c) i = i + (c or 1) end
    while i <= n do
        if pk(2) == "--" and pk(4) == "--[[" then
            local lv=0; local st=i
            if pk(6)=="--[==[" then lv=2; adv(6)
            elseif pk(5)=="--[=[" then lv=1; adv(5) else adv(4) end
            local cl="]"..string.rep("=",lv).."]"
            while i<=n and pk(#cl)~=cl do adv() end
            if i<=n then adv(#cl) end
            toks[#toks+1]={t=TK_CMT, v=src:sub(st,i-1)}
        elseif pk(2)=="--" then
            local st=i; adv(2)
            while i<=n and pk()~="\n" do adv() end
            toks[#toks+1]={t=TK_CMT, v=src:sub(st,i-1)}
        elseif pk()=="\n" or pk()=="\r" then
            adv(); toks[#toks+1]={t=TK_NL, v="\n"}
        elseif pk():match("[ \t\f\v]") then
            adv(); toks[#toks+1]={t=TK_WS, v=" "}
        elseif pk(2)=="[[" or pk(3)=="[=[" or pk(4)=="[==[" then
            local st=i; local lv=0
            if pk(4)=="[==[" then lv=2; adv(4)
            elseif pk(3)=="[=[" then lv=1; adv(3) else adv(2) end
            local cl="]"..string.rep("=",lv).."]"; local content=""
            while i<=n and pk(#cl)~=cl do content=content..pk(); adv() end
            if i<=n then adv(#cl) end
            toks[#toks+1]={t=TK_STR, v=src:sub(st,i-1), sv=content}
        elseif pk()=='"' or pk()=="'" then
            local st=i; local q=pk(); adv(); local s=""
            while i<=n and pk()~=q do
                if pk()=="\\" then
                    adv(); local e=pk()
                    if e=="n" then s=s.."\n"; adv()
                    elseif e=="t" then s=s.."\t"; adv()
                    elseif e=="r" then s=s.."\r"; adv()
                    elseif e=="\\" then s=s.."\\"; adv()
                    elseif e==q then s=s..q; adv()
                    elseif e=="a" then s=s.."\a"; adv()
                    elseif e=="b" then s=s.."\b"; adv()
                    elseif e=="f" then s=s.."\f"; adv()
                    elseif e=="v" then s=s.."\v"; adv()
                    elseif e=="0" then s=s.."\0"; adv()
                    elseif e and tonumber(e:sub(1,1)) then
                        local ns=""
                        for _=1,3 do if i<=n and tonumber(pk()) then ns=ns..pk(); adv() else break end end
                        s=s..string.char(tonumber(ns) or 0)
                    else if i<=n then s=s..pk(); adv() end end
                else s=s..pk(); adv() end
            end
            if i<=n then adv() end
            toks[#toks+1]={t=TK_STR, v=src:sub(st,i-1), sv=s}
        elseif pk():match("[0-9]") or (pk()=="." and pk(2):match("^%.[0-9]")) then
            local st=i
            if pk(2):match("^0[xX]") then
                adv(2); while i<=n and pk():match("[0-9a-fA-F]") do adv() end
            else
                while i<=n and pk():match("[0-9]") do adv() end
                if i<=n and pk()=="." then adv()
                    while i<=n and pk():match("[0-9]") do adv() end
                end
                if i<=n and pk():match("[eE]") then
                    adv()
                    if i<=n and pk():match("[+-]") then adv() end
                    while i<=n and pk():match("[0-9]") do adv() end
                end
            end
            local raw=src:sub(st,i-1)
            toks[#toks+1]={t=TK_NUM, v=raw, nv=tonumber(raw)}
        elseif pk():match("[a-zA-Z_]") then
            local st=i
            while i<=n and pk():match("[a-zA-Z0-9_]") do adv() end
            local raw=src:sub(st,i-1)
            toks[#toks+1]={t=KW[raw] and TK_KW or TK_ID, v=raw}
        elseif pk(3)=="..." then adv(3); toks[#toks+1]={t=TK_OP,v="..."}
        elseif pk(2)=="//=" then adv(2); toks[#toks+1]={t=TK_OP,v="//="}
        elseif pk(2)=="<<" then adv(2); toks[#toks+1]={t=TK_OP,v="<<"}
        elseif pk(2)==">>" then adv(2); toks[#toks+1]={t=TK_OP,v=">>"}
        elseif pk(2)=="//" then adv(2); toks[#toks+1]={t=TK_OP,v="//"}
        elseif pk(2)=="==" then adv(2); toks[#toks+1]={t=TK_OP,v="=="}
        elseif pk(2)=="~=" then adv(2); toks[#toks+1]={t=TK_OP,v="~="}
        elseif pk(2)=="<=" then adv(2); toks[#toks+1]={t=TK_OP,v="<="}
        elseif pk(2)==">=" then adv(2); toks[#toks+1]={t=TK_OP,v=">="}
        elseif pk(2)==".." then adv(2); toks[#toks+1]={t=TK_OP,v=".."}
        else local ch=pk(); adv(1); toks[#toks+1]={t=TK_OP,v=ch} end
    end
    toks[#toks+1]={t=TK_EOF, v=""}
    return toks
end

function M.toSource(toks)
    local p={}
    for _,tk in ipairs(toks) do
        if tk.t~=TK_EOF and tk.t~=TK_CMT then p[#p+1]=tk.v or "" end
    end
    return table.concat(p,"")
end

function M.formatOutput(toks)
    local p={}; local last=nil
    for _,tk in ipairs(toks) do
        if tk.t==TK_EOF or tk.t==TK_CMT then
        elseif tk.t==TK_NL then if last~=TK_NL then p[#p+1]="\n" end
        elseif tk.t==TK_WS then if last and last~=TK_NL and last~=TK_WS then p[#p+1]=" " end
        else p[#p+1]=tk.v or "" end
        last=tk.t
    end
    return table.concat(p,"")
end

return M
