local function f()
    return 42
end
print(f())
print(f)
print(type(f))
