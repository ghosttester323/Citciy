--[[
    ROBLOX LUA OBFUSCATOR v7.0 — CUSTOM VM EDITION
    18 Passes · True Register-Based VM · Custom Bytecode · NO loadstring · NO XOR
--]]

local BASE_DIR = (arg and arg[0]) or "./main.lua"
BASE_DIR = BASE_DIR:match("(.*[/\\])")
if not BASE_DIR then BASE_DIR = "./" end
BASE_DIR = BASE_DIR:gsub("[/\\]$", "")

local function corePath(name) return BASE_DIR .. "/core/" .. name .. ".lua" end
local function passPath(name) return BASE_DIR .. "/passes/" .. name .. ".lua" end

-- Load core
local prng      = dofile(corePath("prng"))
local reserved  = dofile(corePath("reserved"))
local naming    = dofile(corePath("naming"))
local tokenizer = dofile(corePath("tokenizer"))
local utils     = dofile(corePath("utils"))

naming.init(reserved)

local env = {
    prng      = prng,
    reserved  = reserved,
    naming    = naming,
    tokenizer = tokenizer,
    utils     = utils,
    _baseDir  = BASE_DIR,
}

-- Load ALL 18 passes
local passes = {}
passes[1]  = dofile(passPath("pass01_remove_comments"))
passes[2]  = dofile(passPath("pass02_rename"))
passes[3]  = dofile(passPath("pass03_constant_array"))
passes[4]  = dofile(passPath("pass04_string_encrypt"))
passes[5]  = dofile(passPath("pass05_control_flow"))
passes[6]  = dofile(passPath("pass06_dead_functions"))
passes[7]  = dofile(passPath("pass07_wrapper"))
passes[8]  = dofile(passPath("pass08_number_arith"))
passes[9]  = dofile(passPath("pass09_boolean_encode"))
passes[10] = dofile(passPath("pass10_member_index"))
passes[11] = dofile(passPath("pass11_cond_wrap"))
passes[12] = dofile(passPath("pass12_anti_format"))
passes[13] = dofile(passPath("pass13_vm"))
passes[14] = dofile(passPath("pass14_proxy"))
passes[15] = dofile(passPath("pass15_string_split"))
passes[16] = dofile(passPath("pass16_advanced_junk"))
passes[17] = dofile(passPath("pass17_bytecode_encrypt"))
passes[18] = dofile(passPath("pass18_vm_mutate"))

local TOTAL_PASSES = 18

local PASS_NAMES = {
    [1]  = "Removing comments",
    [2]  = "Renaming variables",
    [3]  = "Building constant array",
    [4]  = "Encrypting strings",
    [5]  = "Obfuscating control flow (enhanced)",
    [6]  = "Injecting dead functions",
    [7]  = "Wrapper encapsulation",
    [8]  = "Number arithmetic encoding",
    [9]  = "Boolean encoding",
    [10] = "Member index obfuscation",
    [11] = "Conditional wrapping (enhanced)",
    [12] = "Anti-formatting (enhanced)",
    [13] = "Custom VM (register-based, custom bytecode)",
    [14] = "Proxy functions",
    [15] = "String splitting",
    [16] = "Advanced junk injection (enhanced)",
    [17] = "Bytecode data encryption",
    [18] = "VM mutation layer",
}

-- Passes that operate on raw source strings (not token streams)
local SOURCE_PASSES = {
    [5] = true, [6] = true, [7] = true, [11] = true,
    [12] = true, [13] = true, [14] = true, [16] = true,
    [17] = true, [18] = true,
}

local function obfuscate(source, config)
    local passList = config.passes or {1,2,10,8,15,3,4,9,14,5,6,16,11,13,18,17,7,12}
    prng.setseed(config.seed or os.time())

    print("  [*] Tokenizing...")
    local toks = tokenizer.tokenize(source)
    print("  [*] " .. #toks .. " tokens")

    for idx, pn in ipairs(passList) do
        local name = PASS_NAMES[pn] or ("Pass " .. pn)
        local fn = passes[pn]
        if not fn then
            print("  [PASS " .. pn .. "/" .. TOTAL_PASSES .. "]  SKIP (not loaded)")
        elseif SOURCE_PASSES[pn] then
            print("  [PASS " .. pn .. "/" .. TOTAL_PASSES .. "]  " .. name .. "...")
            local src = tokenizer.toSource(toks)
            src = fn(src, env)
            toks = tokenizer.tokenize(src)
        else
            print("  [PASS " .. pn .. "/" .. TOTAL_PASSES .. "]  " .. name .. "...")
            toks = fn(toks, env)
        end
    end

    print("  [*] Formatting...")
    return tokenizer.formatOutput(toks)
end

local function banner()
    print([[
╔═══════════════════════════════════════════════════════════╗
║     ROBLOX LUA OBFUSCATOR v7.0 — CUSTOM VM EDITION        ║
║     18 Passes · Register-Based VM · Custom Bytecode        ║
║     NO loadstring · NO XOR · TRUE VM EXECUTION             ║
╚═══════════════════════════════════════════════════════════╝
]])
end

local function main(...)
    local args = {...}
    local input, output, seedVal, level, passStr = nil, nil, nil, 3, nil
    local i = 1
    while i <= #args do
        local a = args[i]
        if a == "--help" or a == "-h" then
            banner()
            print("Usage: lua main.lua <input> <output> [options]\n")
            print("Options:")
            print("  --seed <N>       Random seed")
            print("  --level <1-4>    Level (1=light 2=medium 3=heavy 4=max)")
            print("  --passes <list>  Comma-separated pass numbers\n")
            print("Passes:")
            for p = 1, TOTAL_PASSES do
                local info = PASS_NAMES[p] or "Unknown"
                print("  " .. string.format("%2d", p) .. " " .. info)
            end
            print("\nLevels:")
            print("  1 = Light     (1, 2, 4, 9, 10, 15)")
            print("  2 = Medium    (1, 2, 4, 5, 9, 10, 14, 15)")
            print("  3 = Heavy     (1-12, 14-16, + VM)")
            print("  4 = MAXIMUM   (all 18 passes)")
            return
        elseif a == "--seed" then i = i + 1; seedVal = tonumber(args[i])
        elseif a == "--level" then i = i + 1; level = tonumber(args[i])
        elseif a == "--passes" then i = i + 1; passStr = args[i]
        elseif not input then input = a
        elseif not output then output = a
        end
        i = i + 1
    end

    if not input or not output then
        banner(); print("Usage: lua main.lua <input> <output>\n"); return
    end

    local f = io.open(input, "r")
    if not f then print("ERROR: Cannot open " .. input); return end
    local source = f:read("*a"); f:close()

    local passList = nil
    if passStr then
        passList = {}
        for p in passStr:gmatch("%d+") do passList[#passList + 1] = tonumber(p) end
    end

    if not passList then
        if level == 1 then
            passList = {1, 2, 4, 9, 10, 15}
        elseif level == 2 then
            passList = {1, 2, 4, 5, 9, 10, 14, 15}
        elseif level == 3 then
            passList = {1, 2, 10, 8, 15, 3, 4, 9, 14, 5, 6, 11, 13, 18, 7, 12}
        else
            passList = {1, 2, 10, 8, 15, 3, 4, 9, 14, 5, 6, 11, 13, 18, 7, 12}
        end
    end

    banner()
    print("  Input:  " .. input .. " (" .. #source .. " bytes)")
    print("  Output: " .. output)
    print("  Seed:   " .. tostring(seedVal or "random"))
    print("  Passes: " .. table.concat(passList, ", ") .. "\n")

    local result = obfuscate(source, { seed = seedVal, passes = passList })
    local of = io.open(output, "w")
    if not of then print("ERROR: Cannot write " .. output); return end
    of:write(result); of:close()

    print("\n  [OK] " .. output .. " (" .. #result .. " bytes, "
        .. math.floor(#result / math.max(1, #source) * 100) .. "%)")
end

if arg and #arg > 0 then
    main(table.unpack(arg))
end

return { obfuscate = obfuscate, env = env }
