local arr = {5, 10, 15, 20, 25}
local sum = 0
for i = 1, #arr do
    sum = sum + arr[i]
end
print("Sum = " .. tostring(sum))
