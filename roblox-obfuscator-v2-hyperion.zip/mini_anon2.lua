print((function() return 42 end)())
