local Vl=print
Vl((function()local _s={178,207,214,214,217,138,208,220,217,215,138,217,204,208,223,221,205,203,222,217,220,139}local _r=""local _o=106 for _i=1,#_s do _r=_r..string["char"](_s[_i]-_o)end return _r end)())
local Ol=function(Ql) return 1 end Ol(97)
local Il = 10
local Dl={Cl=682,Gl=567,Bl=859,Al=372} Dl=nil
local ll = 25
local Sl="BU" local Nl=Sl:upper()
Vl((function()local _s={168,187,201,203,194,202,144,118}local _r=""local _o=86 for _i=1,#_s do _r=_r..string["char"](_s[_i]-_o)end return _r end)() .. (Il + ll))
local Ml=944+16*2-57