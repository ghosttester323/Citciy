----------------------------------------------------------------
-- PASS 08: NUMBER ARITHMETIC ENCODING
-- Replaces number literals with equivalent arithmetic expressions
-- e.g. 100 → (37+63), 25 → (100/4), 15 → (20-5)
----------------------------------------------------------------
return function(toks, env)
    local rng = env.prng.rng
    local pick = env.prng.pick
    local TK_NUM = env.tokenizer.TK_NUM
    local TK_ID = env.tokenizer.TK_ID

    local function encodeNum(nv)
        if nv == 0 then return "0"
        elseif nv < 0 then return "(0-" .. encodeNum(-nv) .. ")"
        elseif nv <= 5 then return tostring(nv)
        elseif nv == math.floor(nv) and nv > 0 then
            local t = rng(1, 4)
            if t == 1 then
                local a = rng(math.max(1, math.floor(nv * 0.2)), math.max(2, math.floor(nv * 0.8)))
                local b = nv - a
                if b > 0 and a > 0 then return "(" .. a .. "+" .. b .. ")" end
                return tostring(nv)
            elseif t == 2 then
                local b = rng(1, math.max(1, math.floor(nv * 0.5)))
                local a = nv + b
                if a > b then return "(" .. a .. "-" .. b .. ")" end
                return tostring(nv)
            elseif t == 3 then
                local divisors = {}
                for d = 2, math.min(nv, 50) do
                    if nv % d == 0 then divisors[#divisors + 1] = d end
                end
                if #divisors > 0 then
                    local d = pick(divisors)
                    return "(" .. d .. "*" .. (nv / d) .. ")"
                end
                return tostring(nv)
            else
                local muls = {}
                for m = 2, 10 do muls[#muls] = nv * m end
                if #muls > 0 then
                    local m = pick(muls)
                    return "(" .. m .. "/" .. m / nv .. ")"
                end
                return tostring(nv)
            end
        else
            local intPart = math.floor(nv)
            local fracPart = nv - intPart
            return "(" .. encodeNum(intPart) .. "+" .. tostring(fracPart) .. ")"
        end
    end

    local result = {}
    for _, tk in ipairs(toks) do
        if tk.t == TK_NUM and tk.nv ~= nil and math.floor(tk.nv) ~= 0 then
            local enc = encodeNum(tk.nv)
            if enc ~= tk.v then
                result[#result + 1] = { t = TK_ID, v = enc }
            else
                result[#result + 1] = tk
            end
        else
            result[#result + 1] = tk
        end
    end
    return result
end
