----------------------------------------------------------------
-- PASS 03: CONSTANT ARRAY (IronBrew-style)
-- Collects all unique number literals, places them in a shuffled
-- array, and replaces each occurrence with an array index lookup
----------------------------------------------------------------
return function(toks, env)
    local genName = env.naming.genName
    local rng = env.prng.rng
    local TK_NUM = env.tokenizer.TK_NUM
    local TK_ID = env.tokenizer.TK_ID
    local TK_WS = env.tokenizer.TK_WS
    local TK_NL = env.tokenizer.TK_NL

    -- Collect unique numbers
    local uniqNums = {}; local seen = {}
    for _, tk in ipairs(toks) do
        if tk.t == TK_NUM and tk.nv ~= nil and not seen[tk.nv] then
            seen[tk.nv] = true; uniqNums[#uniqNums + 1] = tk.nv
        end
    end

    if #uniqNums == 0 then return toks end

    -- Shuffle the array positions
    local order = {}
    for idx = 1, #uniqNums do order[idx] = idx end
    for i = #order, 2, -1 do local j = rng(1, i); order[i], order[j] = order[j], order[i] end

    local shuffledVals = {}; local numToPos = {}
    for pos, origIdx in ipairs(order) do
        shuffledVals[pos] = uniqNums[origIdx]; numToPos[uniqNums[origIdx]] = pos
    end

    local arrName = genName()
    local entries = {}
    for _, v in ipairs(shuffledVals) do entries[#entries + 1] = tostring(v) end
    local arrDecl = "local " .. arrName .. "={" .. table.concat(entries, ",") .. "}"

    -- Replace number tokens with array lookups
    local result = {}
    for _, tk in ipairs(toks) do
        if tk.t == TK_NUM and numToPos[tk.nv] then
            result[#result + 1] = { t = TK_ID, v = arrName .. "[" .. numToPos[tk.nv] .. "]" }
        else
            result[#result + 1] = tk
        end
    end

    -- Insert array declaration at top
    local ins = 1
    while ins <= #result and (result[ins].t == TK_WS or result[ins].t == TK_NL) do ins = ins + 1 end
    table.insert(result, ins, { t = TK_ID, v = arrDecl })
    table.insert(result, ins + 1, { t = TK_NL, v = "\n" })

    return result
end
