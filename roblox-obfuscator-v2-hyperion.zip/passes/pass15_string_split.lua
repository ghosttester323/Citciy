----------------------------------------------------------------
-- PASS 15: STRING SPLITTING (runtime concatenation)
-- Splits long strings into random-length chunks concatenated at runtime
-- e.g. "Hello World" → ("Hel" .. "lo " .. "World")
----------------------------------------------------------------
return function(toks, env)
    local rng = env.prng.rng
    local TK_STR = env.tokenizer.TK_STR
    local TK_ID = env.tokenizer.TK_ID

    local function escapeForQuote(s, q)
        local r = s
        if q == '"' then
            r = r:gsub("\\", "\\\\"):gsub('"', '\\"')
        else
            r = r:gsub("\\", "\\\\"):gsub("'", "\\'")
        end
        r = r:gsub("\n", "\\n"):gsub("\t", "\\t"):gsub("\r", "\\r")
        return r
    end

    local result = {}
    for _, tk in ipairs(toks) do
        if tk.t == TK_STR and tk.sv and #tk.sv > 8 then
            local str = tk.sv
            local chunks = {}
            local i = 1
            while i <= #str do
                local remaining = #str - i + 1
                local len = math.min(remaining, remaining <= 2 and remaining or rng(2, math.min(6, remaining)))
                chunks[#chunks + 1] = str:sub(i, i + len - 1)
                i = i + len
            end
            if #chunks > 1 then
                local parts = {}
                for _, chunk in ipairs(chunks) do
                    local q = rng(1, 2) == 1 and '"' or "'"
                    parts[#parts + 1] = q .. escapeForQuote(chunk, q) .. q
                end
                local expr = "(" .. table.concat(parts, " .. ") .. ")"
                result[#result + 1] = { t = TK_ID, v = expr }
            else
                result[#result + 1] = tk
            end
        else
            result[#result + 1] = tk
        end
    end
    return result
end
