----------------------------------------------------------------
-- PASS 06: DEAD FUNCTION INJECTION
-- Adds unused local function declarations throughout the code
-- to confuse deobfuscators and reverse engineers
----------------------------------------------------------------
return function(source, env)
    local rng = env.prng.rng
    local genName = env.naming.genName
    local pick = env.prng.pick
    local utils = env.utils

    local lines = utils.splitLines(source)
    if #lines == 0 then return source end

    local function deadFunc()
        local fn, p1, p2, v1 = genName(), genName(), genName(), genName()
        return pick({
            "local function " .. fn .. "(" .. p1 .. "," .. p2 .. ") local " .. v1 .. "=0 for " .. p2 .. "=1,50 do " .. v1 .. "=" .. v1 .. "+1 end return " .. v1 .. " end",
            "local function " .. fn .. "(" .. p1 .. ") return type(" .. p1 .. ") end",
            "local function " .. fn .. "(" .. p1 .. "," .. p2 .. ") local " .. v1 .. "={} return #" .. v1 .. " end",
            "local function " .. fn .. "(" .. p1 .. ") local " .. v1 .. "=" .. rng(1, 9999) .. " if " .. v1 .. ">0 then return " .. v1 .. " end return 0 end",
            "local function " .. fn .. "(" .. p1 .. "," .. p2 .. ") local " .. v1 .. "=" .. p1 .. "+" .. p2 .. " return " .. v1 .. "-" .. p2 .. " end",
        })
    end

    local safe = {}
    for i = 1, #lines do
        if utils.isSafeLine(lines[i]) then safe[#safe + 1] = i end
    end

    local after = {}
    if #safe > 2 then
        for i = #safe, 2, -1 do local j = rng(1, i); safe[i], safe[j] = safe[j], safe[i] end
        local cnt = math.min(rng(3, 8), #safe)
        for ii = 1, cnt do after[safe[ii]] = true end
    end

    local result = {}
    for i = 1, #lines do
        result[#result + 1] = lines[i]
        if after[i] then result[#result + 1] = deadFunc() end
    end
    return utils.joinLines(result)
end
