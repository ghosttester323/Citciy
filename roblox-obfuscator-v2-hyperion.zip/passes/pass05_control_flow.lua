-- PASS 05: CONTROL FLOW OBFUSCATION (ENHANCED)
-- Now includes: switch-like fake dispatch, bogus math chains,
-- fake table manipulation, nested opaque conditions, and more
return function(source, env)
    local rng = env.prng.rng
    local genName = env.naming.genName
    local pick = env.prng.pick
    local utils = env.utils

    local lines = utils.splitLines(source)
    if #lines == 0 then return source end

    local function opaque()
        return utils.opaque(rng)
    end

    local safe = {}
    for i = 1, #lines do
        if utils.isSafeLine(lines[i]) then safe[#safe + 1] = i end
    end

    local after = {}
    if #safe > 2 then
        for i = #safe, 2, -1 do local j = rng(1, i); safe[i], safe[j] = safe[j], safe[i] end
        local cnt = math.min(rng(5, 15), #safe)
        for ii = 1, cnt do after[safe[ii]] = true end
    end

    local result = {}
    for i = 1, #lines do
        result[#result + 1] = lines[i]
        if after[i] then
            local act = rng(1, 8)
            if act == 1 then
                -- Dead variable with opaque init
                result[#result + 1] = "local " .. genName() .. "=" .. rng(100, 99999)
            elseif act == 2 then
                -- Dead table
                local t = {}
                for _ = 1, rng(2, 8) do t[#t + 1] = rng(1, 99999) end
                result[#result + 1] = "local " .. genName() .. "={" .. table.concat(t, ",") .. "}"
            elseif act == 3 then
                -- Opaque if-end
                result[#result + 1] = "if " .. opaque() .. " then end"
            elseif act == 4 then
                -- Pointless arithmetic chain
                local vn = genName()
                local ops = {"+", "-", "*"}
                local chain = tostring(rng(10, 999))
                for _ = 1, rng(2, 5) do
                    local op = pick(ops)
                    local val = rng(1, 100)
                    if op == "*" then val = rng(0, 3) end  -- avoid huge numbers
                    chain = chain .. op .. val
                end
                result[#result + 1] = "local " .. vn .. "=" .. chain
            elseif act == 5 then
                -- Nested opaque conditions
                local v = genName()
                result[#result + 1] = "if " .. opaque() .. " then local " .. v .. "=0 if " .. opaque() .. " then end end"
            elseif act == 6 then
                -- Table manipulation junk
                local tn = genName()
                local entries = {}
                for _ = 1, rng(2, 5) do
                    local k = genName()
                    entries[#entries + 1] = k .. "=" .. rng(1, 999)
                end
                result[#result + 1] = "local " .. tn .. "={" .. table.concat(entries, ",") .. "} " .. tn .. "=nil"
            elseif act == 7 then
                -- Fake function + call
                local fn, p = genName(), genName()
                result[#result + 1] = "local " .. fn .. "=function(" .. p .. ") return " .. rng(0,1) .. " end " .. fn .. "(" .. rng(1,99) .. ")"
            else
                -- String manipulation junk
                local s1, s2 = genName(), genName()
                local chars = {}
                for _ = 1, rng(2, 5) do chars[#chars + 1] = string.char(rng(65, 90)) end
                result[#result + 1] = 'local ' .. s1 .. '="' .. table.concat(chars) .. '" local ' .. s2 .. '=' .. s1 .. ':upper()'
            end
        end
    end
    return utils.joinLines(result)
end
