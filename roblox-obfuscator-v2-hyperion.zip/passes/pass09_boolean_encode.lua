----------------------------------------------------------------
-- PASS 09: BOOLEAN ENCODING
-- Replaces true/false with opaque equivalent expressions
-- e.g. true → (1==1), false → (1==0)
----------------------------------------------------------------
return function(toks, env)
    local pick = env.prng.pick
    local TK_KW = env.tokenizer.TK_KW
    local TK_ID = env.tokenizer.TK_ID

    local trueExprs = {
        "(1==1)",
        "(not false)",
        '(type(nil)=="nil")',
        "(not not true)",
        "(5^0==1)",
        "((3+2)==5)",
        "(not(1==0))",
        '(type(42)=="number")',
    }
    local falseExprs = {
        "(1==0)",
        "(not true)",
        '(type(1)=="string")',
        "(nil==1)",
        "(0>1)",
        "(not(1==1))",
        "((3+2)==6)",
        '(type(nil)=="number")',
    }

    local result = {}
    for _, tk in ipairs(toks) do
        if tk.t == TK_KW and tk.v == "true" then
            result[#result + 1] = { t = TK_ID, v = pick(trueExprs) }
        elseif tk.t == TK_KW and tk.v == "false" then
            result[#result + 1] = { t = TK_ID, v = pick(falseExprs) }
        else
            result[#result + 1] = tk
        end
    end
    return result
end
