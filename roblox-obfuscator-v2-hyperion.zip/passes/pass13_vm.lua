----------------------------------------------------------------
-- PASS 13: CUSTOM VM (Register-based, Custom Bytecode)
-- Compiles Lua source into custom VM bytecode with a register-based
-- architecture, custom instruction set, and encoded bytecode data.
--
-- PLACEHOLDER: Delegates to core/vm.lua for the actual VM implementation.
-- This pass is loaded and called from the main pipeline.
----------------------------------------------------------------
return function(source, env)
    local vm = dofile(env._baseDir .. "/core/vm.lua")
    return vm.process(source, env)
end
