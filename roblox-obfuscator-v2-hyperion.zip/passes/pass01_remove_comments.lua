----------------------------------------------------------------
-- PASS 01: REMOVE COMMENTS
-- Strips all comments (-- and --[[ ]]) from token stream
----------------------------------------------------------------
return function(toks, env)
    local TK_CMT = env.tokenizer.TK_CMT
    local result = {}
    for _, tk in ipairs(toks) do
        if tk.t ~= TK_CMT then
            result[#result + 1] = tk
        end
    end
    return result
end
