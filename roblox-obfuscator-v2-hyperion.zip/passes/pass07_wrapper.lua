----------------------------------------------------------------
-- PASS 07: WRAPPER ENCAPSULATION
-- Wraps the entire script inside 2-3 nested function layers
-- with dummy parameters and arguments
----------------------------------------------------------------
return function(source, env)
    local rng = env.prng.rng
    local genName = env.naming.genName

    local depth = rng(2, 3)
    local layers = {}
    for w = 1, depth do
        local fn = genName(); local params, args = {}, {}; local pcount = rng(0, 2)
        for p = 1, pcount do
            params[p] = genName()
            args[p] = tostring(rng(100, 99999))
        end
        layers[w] = { fn = fn, params = table.concat(params, ","), args = table.concat(args, ",") }
    end

    local result = ""
    for w = 1, depth do
        result = result .. "local function " .. layers[w].fn .. "(" .. layers[w].params .. ")\n"
    end
    result = result .. source .. "\n"
    for w = depth, 1, -1 do
        result = result .. "end\n"
        if w > 1 then result = result .. layers[w].fn .. "(" .. layers[w].args .. ")\n" end
    end
    result = result .. layers[1].fn .. "(" .. layers[1].args .. ")\n"

    return result
end
