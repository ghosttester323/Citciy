----------------------------------------------------------------
-- PASS 16: ADVANCED JUNK INJECTION (ENHANCED)
-- Injects sophisticated dead code patterns: tables with methods,
-- while loops with opaque predicates, recursive functions, multi-variable
-- calculation chains, for-pairs loops, string operations, nested ifs,
-- AND NEW: fake coroutine usage, table.sort with fake comparator,
-- string.byte/char chains, metatable manipulation junk,
-- recursive fibonacci-like functions
----------------------------------------------------------------
return function(source, env)
    local rng = env.prng.rng
    local genName = env.naming.genName
    local pick = env.prng.pick
    local utils = env.utils

    local lines = utils.splitLines(source)
    if #lines == 0 then return source end

    local function opaque()
        local a, b = rng(100, 9999), rng(100, 9999)
        return pick({
            "(not false)",
            "(" .. a .. "+" .. b .. "-" .. a .. "==" .. b .. ")",
            '(type(' .. rng(10, 999) .. ')=="number")',
            "((" .. a .. "+" .. b .. ")^0==1)",
            "(not not true)",
            "(" .. (a * 1) .. "==" .. a .. ")",
            "(" .. (a + 0) .. ">" .. (b - b) .. ")",
        })
    end

    local function junkBlock()
        local kind = rng(1, 13)
        if kind == 1 then
            -- Table with methods
            local tn = genName()
            local m1, m2 = genName(), genName()
            local v = genName()
            return "local " .. tn .. "={} " .. tn .. "." .. m1 .. "=function(" .. v .. ") return " .. v .. " end "
                .. tn .. "." .. m2 .. "=function(" .. v .. ") return type(" .. v .. ") end"
        elseif kind == 2 then
            -- While loop with opaque predicate
            local v1, v2, c = genName(), genName(), genName()
            return "local " .. v1 .. "=0 local " .. v2 .. "=0 local " .. c .. "=0 while " .. opaque()
                .. " and " .. c .. "<1 do " .. c .. "=" .. c .. "+1 " .. v1 .. "=" .. v1 .. "+1 end"
        elseif kind == 3 then
            -- Recursive function
            local fn, p, c = genName(), genName(), genName()
            return "local function " .. fn .. "(" .. p .. ") if " .. p .. "<=1 then return 1 end "
                .. c .. "=" .. fn .. "(" .. p .. "-1) return " .. c .. " end"
        elseif kind == 4 then
            -- Multi-variable calculation chain
            local v1, v2, v3 = genName(), genName(), genName()
            local a, b, c = rng(1, 99), rng(1, 99), rng(1, 99)
            return "local " .. v1 .. "=" .. a .. "+" .. b .. " local " .. v2 .. "=" .. v1 .. "-" .. c
                .. " local " .. v3 .. "=" .. v2 .. "+" .. c .. "-" .. b
        elseif kind == 5 then
            -- For loop over garbage table
            local tn, kn, vn = genName(), genName(), genName()
            local entries = {}
            for _ = 1, rng(3, 6) do entries[#entries + 1] = rng(1, 9999) end
            return "local " .. tn .. "={" .. table.concat(entries, ",") .. "} for " .. kn .. "," .. vn
                .. " in pairs(" .. tn .. ") do " .. vn .. "=" .. vn .. "+0 end"
        elseif kind == 6 then
            -- String operation junk
            local v1, v2 = genName(), genName()
            local s1 = string.char(rng(65, 90), rng(65, 90), rng(65, 90))
            local s2 = string.char(rng(65, 90), rng(65, 90))
            return 'local ' .. v1 .. '="' .. s1 .. '" local ' .. v2 .. '=' .. v1 .. ':sub(1,2) local ' .. v2 .. '="' .. s2 .. '"'
        elseif kind == 7 then
            -- Nested if with always-false condition
            local v = genName()
            return "local " .. v .. "=" .. rng(1, 9999) .. " if " .. v .. ">" .. (rng(10000, 99999))
                .. " then " .. v .. "=" .. v .. "+1 elseif " .. v .. "<0 then " .. v .. "=0 end"
        elseif kind == 8 then
            -- Number table + scan
            local tn, vn = genName(), genName()
            local entries = {}
            for _ = 1, rng(4, 8) do entries[#entries + 1] = rng(1, 9999) end
            return "local " .. tn .. "={" .. table.concat(entries, ",") .. "} "
                .. "for " .. vn .. "=1,#" .. tn .. " do if " .. tn .. "[" .. vn .. "]<0 then "
                .. tn .. "[" .. vn .. "]=0 end end"
        elseif kind == 9 then
            -- Fake coroutine usage
            local coVar = genName()
            local fnVar = genName()
            local pVar = genName()
            return "local " .. coVar .. "=coroutine.create(function(" .. pVar .. ") end) "
                .. "coroutine.resume(" .. coVar .. ")"
        elseif kind == 10 then
            -- Table.sort with fake comparator
            local tn = genName()
            local vn1 = genName()
            local vn2 = genName()
            local entries = {}
            for _ = 1, rng(3, 7) do entries[#entries + 1] = rng(1, 9999) end
            return "local " .. tn .. "={" .. table.concat(entries, ",") .. "} "
                .. "table.sort(" .. tn .. ",function(" .. vn1 .. "," .. vn2 .. ") return " .. vn1 .. "<" .. vn2 .. " end)"
        elseif kind == 11 then
            -- String.byte / string.char chains
            local v1 = genName()
            local v2 = genName()
            local bytes = {}
            for _ = 1, rng(2, 5) do bytes[#bytes + 1] = rng(65, 122) end
            return "local " .. v1 .. "=string.char(" .. table.concat(bytes, ",") .. ") "
                .. "local " .. v2 .. "=string.byte(" .. v1 .. ",1)"
        elseif kind == 12 then
            -- Metatable manipulation junk
            local tn = genName()
            local mt = genName()
            local key = genName()
            local entries = {}
            for _ = 1, rng(2, 4) do
                entries[#entries + 1] = rng(1, 999)
            end
            return "local " .. tn .. "={" .. table.concat(entries, ",") .. "} "
                .. "local " .. mt .. "={" .. key .. "=function() end} "
                .. "setmetatable(" .. tn .. "," .. mt .. ")"
        else
            -- Recursive fibonacci-like function
            local fn = genName()
            local p = genName()
            local c1 = genName()
            local c2 = genName()
            return "local function " .. fn .. "(" .. p .. ") if " .. p .. "<=2 then return 1 end "
                .. c1 .. "=" .. fn .. "(" .. p .. "-1) " .. c2 .. "=" .. fn .. "(" .. p .. "-2) "
                .. "return " .. c1 .. "+" .. c2 .. " end"
        end
    end

    local safe = {}
    for i = 1, #lines do if utils.isSafeLine(lines[i]) then safe[#safe + 1] = i end end

    local after = {}
    if #safe > 2 then
        for i = #safe, 2, -1 do local j = rng(1, i); safe[i], safe[j] = safe[j], safe[i] end
        local cnt = math.min(rng(5, 14), #safe)
        for ii = 1, cnt do after[safe[ii]] = true end
    end

    local result = {}
    for i = 1, #lines do
        result[#result + 1] = lines[i]
        if after[i] then
            result[#result + 1] = junkBlock()
        end
    end
    return utils.joinLines(result)
end
