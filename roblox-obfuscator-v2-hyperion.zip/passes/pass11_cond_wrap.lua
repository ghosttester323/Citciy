----------------------------------------------------------------
-- PASS 11: CONDITIONAL WRAPPING (ENHANCED)
-- Wraps statements in opaque if-then-end, while-do-end, repeat-until blocks
----------------------------------------------------------------
return function(source, env)
    local rng = env.prng.rng
    local genName = env.naming.genName
    local pick = env.prng.pick
    local utils = env.utils

    local lines = utils.splitLines(source)
    if #lines == 0 then return source end

    local function opaque()
        local a, b = rng(100, 9999), rng(100, 9999)
        return pick({
            "(not false)",
            "(" .. a .. "+" .. b .. "-" .. a .. "==" .. b .. ")",
            '(type(' .. rng(10, 999) .. ')=="number")',
            "((" .. a .. "+" .. b .. ")^0==1)",
            "(not not true)",
            "(" .. (a * 1) .. "==" .. a .. ")",
        })
    end

    local function isWrapSafe(line)
        if not utils.isSafeLine(line) then return false end
        local t = line:match("^%s*(.-)%s*$")
        if t:match("^local[%s]") or t == "local" then return false end
        if t:match("^local function") or t:match("^function ") then return false end
        if t:match("^return") then return false end
        return true
    end

    local safe = {}
    for i = 1, #lines do
        if isWrapSafe(lines[i]) then safe[#safe + 1] = i end
    end

    local after = {}
    if #safe > 2 then
        for i = #safe, 2, -1 do local j = rng(1, i); safe[i], safe[j] = safe[j], safe[i] end
        local cnt = math.min(rng(4, 10), #safe)
        for ii = 1, cnt do after[safe[ii]] = true end
    end

    local result = {}
    for i = 1, #lines do
        if after[i] then
            local wrapType = rng(1, 3)
            if wrapType == 1 then
                -- if-then-end
                result[#result + 1] = "if " .. opaque() .. " then"
                result[#result + 1] = lines[i]
                result[#result + 1] = "end"
            elseif wrapType == 2 then
                -- while-do-end (runs once)
                local cv = genName()
                result[#result + 1] = "local " .. cv .. "=0 while " .. opaque() .. " and " .. cv .. "<1 do " .. cv .. "=" .. cv .. "+1 "
                result[#result + 1] = lines[i]
                result[#result + 1] = " end"
            else
                -- repeat-until (runs once)
                local cv = genName()
                result[#result + 1] = "local " .. cv .. "=0 repeat " .. lines[i] .. " " .. cv .. "=" .. cv .. "+1 until " .. cv .. ">=1"
            end
        else
            result[#result + 1] = lines[i]
        end
    end
    return utils.joinLines(result)
end
