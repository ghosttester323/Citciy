----------------------------------------------------------------
-- PASS 02: VARIABLE RENAMING
-- Scope-aware renaming of local variables and function names
-- Protects all Roblox API names and reserved identifiers
----------------------------------------------------------------
return function(toks, env)
    local R = env.reserved
    local genName = env.naming.genName
    local TK_ID = env.tokenizer.TK_ID
    local TK_KW = env.tokenizer.TK_KW
    local TK_WS = env.tokenizer.TK_WS
    local TK_OP = env.tokenizer.TK_OP

    local function skipWS(idx)
        while idx <= #toks and toks[idx].t == TK_WS do idx = idx + 1 end
        return idx
    end

    local rmap = {}
    local function addR(name)
        if not R[name] and not rmap[name] then rmap[name] = genName() end
    end

    local function collectParams(si)
        local k = si + 1
        while k <= #toks do
            k = skipWS(k)
            if k <= #toks and toks[k].t == TK_ID then addR(toks[k].v); k = k + 1
            elseif k <= #toks and toks[k].t == TK_OP and toks[k].v == "..." then k = k + 1
            elseif k <= #toks and toks[k].t == TK_OP and toks[k].v == "," then k = k + 1
            elseif k <= #toks and toks[k].t == TK_OP and toks[k].v == ")" then break
            else k = k + 1 end
        end
    end

    -- First pass: collect all renameable names
    for i = 1, #toks do
        local tk = toks[i]
        if tk.t ~= TK_KW then goto nxt end

        if tk.v == "local" then
            local j = skipWS(i + 1)
            if j <= #toks and toks[j].t == TK_KW and toks[j].v == "function" then
                local k = skipWS(j + 1)
                if k <= #toks and toks[k].t == TK_ID then
                    addR(toks[k].v); k = skipWS(k + 1)
                    if k <= #toks and toks[k].t == TK_OP and toks[k].v == "(" then collectParams(k) end
                end; goto nxt
            end
            if j <= #toks and toks[j].t == TK_ID then
                addR(toks[j].v); j = skipWS(j + 1)
                while j <= #toks and toks[j].t == TK_OP and toks[j].v == "," do
                    j = skipWS(j + 1)
                    if j <= #toks and toks[j].t == TK_ID then addR(toks[j].v); j = skipWS(j + 1)
                    else break end
                end
            end; goto nxt
        end

        if tk.v == "function" then
            local prev = i - 1
            while prev >= 1 and toks[prev].t == TK_WS do prev = prev - 1 end
            if prev >= 1 and toks[prev].t == TK_OP and (toks[prev].v == "." or toks[prev].v == ":") then goto nxt end
            local k = skipWS(i + 1)
            if k <= #toks and toks[k].t == TK_ID then
                addR(toks[k].v); k = skipWS(k + 1)
                if k <= #toks and toks[k].t == TK_OP and toks[k].v == "(" then collectParams(k) end
            end; goto nxt
        end

        if tk.v == "for" then
            local k = skipWS(i + 1)
            while true do
                k = skipWS(k)
                if k <= #toks and toks[k].t == TK_ID then
                    addR(toks[k].v); k = k + 1; k = skipWS(k)
                    if k <= #toks and toks[k].t == TK_OP and toks[k].v == "," then k = k + 1 else break end
                else break end
            end
        end

        ::nxt::
    end

    -- Second pass: apply renames (skip after . or :)
    local result = {}
    for i = 1, #toks do
        local tk = toks[i]
        if tk.t == TK_ID and rmap[tk.v] then
            local prev = i - 1
            while prev >= 1 and toks[prev].t == TK_WS do prev = prev - 1 end
            if prev >= 1 and toks[prev].t == TK_OP and (toks[prev].v == "." or toks[prev].v == ":") then
                result[#result + 1] = tk
            else
                result[#result + 1] = { t = TK_ID, v = rmap[tk.v] }
            end
        else
            result[#result + 1] = tk
        end
    end
    return result
end
