----------------------------------------------------------------
-- PASS 04: STRING ENCRYPTION (char code offset, NO XOR)
-- Each string is replaced with a runtime decryption IIFE that
-- shifts each character code by a random offset
----------------------------------------------------------------
return function(toks, env)
    local rng = env.prng.rng
    local TK_STR = env.tokenizer.TK_STR
    local TK_ID = env.tokenizer.TK_ID

    local result = {}
    for _, tk in ipairs(toks) do
        if tk.t ~= TK_STR or not tk.sv or #tk.sv == 0 then
            result[#result + 1] = tk
        else
            local str = tk.sv
            local offset = rng(17, 137)
            local codes = {}
            for ci = 1, #str do codes[ci] = string.byte(str, ci) + offset end
            local codeStr = table.concat(codes, ",")
            local expr = "(function()local _s={" .. codeStr
                .. "}local _r=\"\"local _o=" .. offset
                .. " for _i=1,#_s do _r=_r..string.char(_s[_i]-_o)end return _r end)()"
            result[#result + 1] = { t = TK_ID, v = expr }
        end
    end
    return result
end
