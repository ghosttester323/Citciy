----------------------------------------------------------------
-- PASS 10: MEMBER INDEX OBFUSCATION
-- Converts dot access to bracket access:
--   obj.Name → obj["Name"]
-- Preserves colon (:) access for method calls
----------------------------------------------------------------
return function(toks, env)
    local TK_OP = env.tokenizer.TK_OP
    local TK_ID = env.tokenizer.TK_ID
    local TK_STR = env.tokenizer.TK_STR
    local TK_WS = env.tokenizer.TK_WS

    local result = {}
    for i, tk in ipairs(toks) do
        if tk.t == TK_OP and (tk.v == "." or tk.v == ":") then
            local j = i + 1
            while j <= #toks and toks[j].t == TK_WS do j = j + 1 end
            if j <= #toks and toks[j].t == TK_ID then
                local memberName = toks[j].v
                if tk.v == "." then
                    result[#result + 1] = { t = TK_OP, v = "[" }
                    result[#result + 1] = { t = TK_STR, v = '"' .. memberName .. '"', sv = memberName }
                    result[#result + 1] = { t = TK_OP, v = "]" }
                    toks[j].t = TK_WS; toks[j].v = ""
                else
                    result[#result + 1] = tk
                end
            else
                result[#result + 1] = tk
            end
        else
            result[#result + 1] = tk
        end
    end
    return result
end
