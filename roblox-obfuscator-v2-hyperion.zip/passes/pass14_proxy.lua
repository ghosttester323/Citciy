----------------------------------------------------------------
-- PASS 14: PROXY FUNCTIONS (indirect API calls)
-- Replaces global function calls (print, pairs, etc.) with calls
-- through local proxy variables to make static analysis harder
----------------------------------------------------------------
local PROXY_TARGETS = {
    "print", "warn", "error", "pairs", "ipairs", "type", "typeof",
    "tostring", "tonumber", "pcall", "xpcall", "wait", "spawn",
    "delay", "tick", "time", "require",
}

return function(source, env)
    local genName = env.naming.genName

    -- Find which targets are actually used
    local used = {}
    for _, name in ipairs(PROXY_TARGETS) do
        local found = false
        local i = 1
        while i <= #source do
            local pos = source:find(name, i, true)
            if not pos then break end
            local before = pos > 1 and source:sub(pos - 1, pos - 1) or ""
            local afterChar = source:sub(pos + #name, pos + #name) or ""
            if before:match("[%a_%.:]") then
                i = pos + 1
            elseif afterChar:match("[%a_]") then
                i = pos + 1
            else
                found = true; break
            end
        end
        if found then used[#used + 1] = name end
    end

    if #used == 0 then return source end

    local proxies = {}
    local decls = {}
    for _, name in ipairs(used) do
        local proxy = genName()
        proxies[name] = proxy
        decls[#decls + 1] = "local " .. proxy .. "=" .. name
    end

    local function replaceWord(src, word, replacement)
        local result = {}
        local i = 1
        while i <= #src do
            if src:sub(i, i + #word - 1) == word then
                local before = i > 1 and src:sub(i - 1, i - 1) or ""
                local afterChar = src:sub(i + #word, i + #word) or ""
                if not before:match("[%a_%.:]") and not afterChar:match("[%a_]") then
                    result[#result + 1] = replacement
                    i = i + #word
                else
                    result[#result + 1] = src:sub(i, i)
                    i = i + 1
                end
            else
                result[#result + 1] = src:sub(i, i)
                i = i + 1
            end
        end
        return table.concat(result)
    end

    local result = source
    for _, name in ipairs(used) do
        result = replaceWord(result, name, proxies[name])
    end

    return table.concat(decls, "\n") .. "\n" .. result
end
