----------------------------------------------------------------
-- PASS 17: DATA ENCRYPTION LAYER
-- Wraps the entire output in a function that decodes and executes
-- the original script using a simple character offset cipher.
-- Uses load() which IS available in Roblox Server scripts (Lua 5.1)
-- and plugins/command bar. For strict no-load environments, skip this pass.
----------------------------------------------------------------
return function(source, env)
    local rng = env.prng.rng
    local genName = env.naming.genName

    -- Encode source as char codes with random offset per block
    local blockSize = rng(32, 128)
    local blocks = {}
    local offsets = {}

    local idx = 1
    while idx <= #source do
        local block = {}
        local offset = rng(1, 200)
        offsets[#offsets + 1] = offset
        for j = 1, blockSize do
            if idx > #source then break end
            block[j] = string.byte(source, idx) + offset
            idx = idx + 1
        end
        blocks[#blocks + 1] = block
    end

    -- Generate decoder
    local fnName = genName()
    local blocksVar = genName()
    local offsetsVar = genName()
    local resultVar = genName()
    local bVar = genName()
    local iVar = genName()
    local jVar = genName()

    local blockStrs = {}
    for bi, block in ipairs(blocks) do
        blockStrs[#blockStrs + 1] = "{" .. table.concat(block, ",") .. "}"
    end

    local output = "local function " .. fnName .. "()\n"
    output = output .. "local " .. blocksVar .. "={" .. table.concat(blockStrs, ",") .. "}\n"
    output = output .. "local " .. offsetsVar .. "={" .. table.concat(offsets, ",") .. "}\n"
    output = output .. "local " .. resultVar .. '=""' .. "\n"
    output = output .. "for " .. bVar .. "=1,#" .. blocksVar .. " do\n"
    output = output .. "local " .. iVar .. "=" .. offsetsVar .. "[" .. bVar .. "]\n"
    output = output .. "for " .. jVar .. "=1,#" .. blocksVar .. "[" .. bVar .. "] do\n"
    output = output .. resultVar .. "=" .. resultVar .. "..string.char(" .. blocksVar .. "[" .. bVar .. "][" .. jVar .. "]-" .. iVar .. ")\n"
    output = output .. "end\n"
    output = output .. "end\n"
    output = output .. "return " .. resultVar .. "\n"
    output = output .. "end\n"

    -- Decode and execute using load
    local srcVar = genName()
    output = output .. "local " .. srcVar .. "=" .. fnName .. "()\n"
    output = output .. "load(" .. srcVar .. ")()\n"

    return output
end
