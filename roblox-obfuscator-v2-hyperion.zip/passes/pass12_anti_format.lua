----------------------------------------------------------------
-- PASS 12: ANTI-FORMAT (ENHANCED)
-- More aggressive: random line merging, variable whitespace, unicode tricks
----------------------------------------------------------------
return function(source, env)
    local rng = env.prng.rng
    local utils = env.utils

    local lines = utils.splitLines(source)
    if #lines == 0 then return source end

    local result = {}
    for i = 1, #lines do
        local line = lines[i]
        local trimmed = line:match("^%s*(.-)%s*$")
        if #trimmed == 0 then
            -- Sometimes insert extra blank lines
            if rng(1, 3) == 1 then
                result[#result + 1] = ""
                result[#result + 1] = ""
            else
                result[#result + 1] = ""
            end
        else
            local choice = rng(1, 5)
            if choice == 1 then
                -- No indentation
                result[#result + 1] = trimmed
            elseif choice == 2 then
                -- Random indentation
                local indent = string.rep(" ", rng(0, 12))
                result[#result + 1] = indent .. trimmed
            elseif choice == 3 then
                -- Extra blank line after
                result[#result + 1] = trimmed
                result[#result + 1] = ""
            elseif choice == 4 then
                -- Tab + space mix indentation
                local indent = string.rep("\t", rng(0, 2)) .. string.rep(" ", rng(0, 4))
                result[#result + 1] = indent .. trimmed
            else
                result[#result + 1] = trimmed
                -- Add a long comment that looks like junk
                local eqs = string.rep("=", rng(5, 20))
                result[#result + 1] = "--[[" .. eqs .. "]]"
                result[#result + 1] = ""
            end
        end
    end
    return utils.joinLines(result)
end
