----------------------------------------------------------------
-- PASS 18: VM MUTATION LAYER
-- Post-processes VM output to add decoy data tables,
-- fake invocations, and structural noise.
----------------------------------------------------------------
return function(source, env)
    local rng = env.prng.rng
    local genName = env.naming.genName
    local pick = env.prng.pick
    local utils = env.utils

    local lines = utils.splitLines(source)
    if #lines == 0 then return source end

    local result = {}

    -- Find lines with large number tables and add decoy tables near them
    for i = 1, #lines do
        result[#result + 1] = lines[i]

        -- Detect data table lines (contain {1,2,3,...} patterns)
        if lines[i]:match("%{%d+") and #lines[i] > 50 then
            -- Insert decoy tables before and after
            if rng(1, 2) == 1 then
                local decoyName = genName()
                local decoySize = rng(20, 100)
                local decoyVals = {}
                for _ = 1, decoySize do
                    decoyVals[#decoyVals + 1] = rng(1, 99999)
                end
                result[#result + 1] = "local " .. decoyName .. "={" .. table.concat(decoyVals, ",") .. "}"
            end

            -- Insert fake computation
            if rng(1, 3) == 1 then
                local v1 = genName()
                local v2 = genName()
                local decoy = genName()
                result[#result + 1] = "local " .. v1 .. "=" .. rng(1,9999)
                result[#result + 1] = "local " .. v2 .. "=" .. rng(1,9999)
                result[#result + 1] = "local " .. decoy .. "=(" .. v1 .. "+" .. v2 .. ")%256"
            end
        end

        -- Detect function definitions and add dummy calls nearby
        if lines[i]:match("^local function") and rng(1, 3) == 1 then
            local dummyFn = genName()
            result[#result + 1] = "local " .. dummyFn .. "=function() return nil end"
        end

        -- Detect "for" dispatch loops and add decoy entries
        if lines[i]:match("^for ") and lines[i]:match("do") and rng(1, 4) == 1 then
            local decoyVar = genName()
            result[#result + 1] = "if " .. decoyVar .. "~=nil then " .. decoyVar .. "=nil end"
        end
    end

    return utils.joinLines(result)
end
