-- Test Script (Pure Lua)
local message = "Hello, World!"
print(message)

local x = 10
local y = 25
local result = x + y
print("Result: " .. result)

local total = 0
for i = 1, 5 do
    total = total + i
end
print("Total: " .. total)

local names = {"Alice", "Bob", "Charlie"}
for idx, name in pairs(names) do
    print("Player " .. idx .. ": " .. name)
end

local function greet(who)
    return "Welcome, " .. who .. "!"
end
print(greet("Roblox"))
