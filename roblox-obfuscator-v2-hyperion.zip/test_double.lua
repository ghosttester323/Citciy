local function inc(x)
    return x + 1
end
local function double(x)
    return inc(inc(x))
end
print("double(5) = " .. tostring(double(5)))
