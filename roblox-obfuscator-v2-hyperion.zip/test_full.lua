-- Test complet pour obfuscation toutes passes
-- Variables, operations, strings, tables, loops, functions, etc.

local x = 10
local y = 20
local result = x + y * 2
print("Result: " .. tostring(result))

local t = {name = "Obfuscator", version = 7, alive = true}
for k, v in pairs(t) do
    print(k .. " = " .. tostring(v))
end

local arr = {5, 10, 15, 20, 25}
local sum = 0
for i = 1, #arr do
    sum = sum + arr[i]
end
print("Sum = " .. tostring(sum))

local function fibonacci(n)
    if n <= 1 then return n end
    return fibonacci(n - 1) + fibonacci(n - 2)
end
print("Fib(10) = " .. tostring(fibonacci(10)))

if result > 30 then
    print("PASS: result > 30")
else
    print("FAIL: result <= 30")
end

local function greet(name)
    return "Hello, " .. name .. "!"
end
print(greet("World"))
print(greet("VM"))

local empty = nil
if not empty then
    print("nil check: OK")
end

local count = 0
while count < 5 do
    count = count + 1
end
print("While count: " .. tostring(count))

print("=== ALL TESTS PASSED ===")
