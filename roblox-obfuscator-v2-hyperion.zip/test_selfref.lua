local function f()
    return f()
end
print(type(f()))
