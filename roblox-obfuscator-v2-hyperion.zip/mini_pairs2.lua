for k,v in pairs({10,20,30}) do print(k,v) end
