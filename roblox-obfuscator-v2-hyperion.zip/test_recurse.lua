local function count(n)
    if n <= 0 then return 0 end
    return n + count(n - 1)
end
print("count(5) = " .. tostring(count(5)))
