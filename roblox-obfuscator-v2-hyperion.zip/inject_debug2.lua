local content = io.open('t.lua','r'):read('*a')

-- Add step counter
content = content:gsub(
  "Cl=1",
  "local _dbgSteps=0 Cl=1"
)
content = content:gsub(
  "while Cl<=#",
  "_dbgSteps=_dbgSteps+1 if _dbgSteps>50 then print('TOO MANY STEPS') return nil end while Cl<=#"
)

-- Add PC debug before op dispatch
content = content:gsub(
  "local w=",
  "if _dbgSteps<=20 then print('pc='..Cl..' step='.._dbgSteps) end local w="
)

-- Add debug for return
content = content:gsub(
  "elseif Hl==27 then return",
  "elseif Hl==27 then print('RETURN pc='..Cl..' ra='..Kl..' val='..tostring(Dl[Kl])) return"
)

-- Add debug for call
content = content:gsub(
  "elseif Hl==26 then",
  "elseif Hl==26 then print('CALL pc='..Cl..' ra='..Kl..' nargs='..Rl)"
)

-- Add debug for closure
content = content:gsub(
  "elseif Hl==36 then",
  "elseif Hl==36 then print('CLOSURE pc='..Cl..' ra='..Kl)"
)

io.open('t_debug.lua','w'):write(content):close()
