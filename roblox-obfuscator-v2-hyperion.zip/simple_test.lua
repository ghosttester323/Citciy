print("Hello from obfuscator!")
local x = 10
local y = 25
print("Result: " .. (x + y))
