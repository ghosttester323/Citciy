-- Test pour toutes les passes - SANS fonctions locales
local x = 10
local y = 20
local result = x + y * 2
print("Result: " .. tostring(result))

local t = {name = "Obfuscator", version = 7, alive = true}
for k, v in pairs(t) do
    print(k .. " = " .. tostring(v))
end

local arr = {5, 10, 15, 20, 25}
local sum = 0
for i = 1, #arr do
    sum = sum + arr[i]
end
print("Sum = " .. tostring(sum))

local fib = {0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55}
print("Fib(10) = " .. tostring(fib[11]))

if result > 30 then
    print("PASS: result > 30")
else
    print("FAIL: result <= 30")
end

local empty = nil
if not empty then
    print("nil check: OK")
end

local count = 0
while count < 5 do
    count = count + 1
end
print("While count: " .. tostring(count))

print("Len of 'abc': " .. tostring(#"abc"))

print("3 + 4 = " .. tostring(3 + 4))
print("100 / 3 = " .. tostring(100 / 3))
print("2 ^ 10 = " .. tostring(2 ^ 10))

local mt = {}
mt.key1 = "value1"
mt[42] = "answer"
print("mt.key1 = " .. mt.key1)
print("mt[42] = " .. tostring(mt[42]))

repeat
    count = count - 1
until count <= 0
print("Repeat count: " .. tostring(count))

print("=== ALL TESTS PASSED ===")
