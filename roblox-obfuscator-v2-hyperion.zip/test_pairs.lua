-- Test script for PAIRSLOOP fix
local t = {a = 1, b = 2, c = 3, d = 4}
print("=== pairs test ===")
for k, v in pairs(t) do
    print(k, v)
end

print("=== ipairs test ===")
local arr = {10, 20, 30}
for i, v in ipairs(arr) do
    print(i, v)
end

print("=== nested pairs ===")
local nested = {x = {p = 100, q = 200}, y = {r = 300}}
for k1, v1 in pairs(nested) do
    print("outer:", k1)
    for k2, v2 in pairs(v1) do
        print("  inner:", k2, v2)
    end
end

print("=== DONE ===")
