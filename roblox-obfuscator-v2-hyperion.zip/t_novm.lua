print((function()local _s={135,136}local _r=""local _o=31 for _i=1,#_s do _r=_r..string.char(_s[_i]-_o)end return _r end)())
