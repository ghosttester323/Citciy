local x = string.char(72) print(x)
