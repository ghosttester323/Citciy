local ll={32140,33472,42061,33853,11244,19444,29681,9398,7803,15367,51821,18580,1881302178,2418437348,1747234635,1746941459,1811979597,49815,43174,46349,59454,50209,39921,55340,1947,14685,12914,17329,57586,27522,12006,26460,50846,15709,45739,26953,63040,34034,29648,65127,35917,44015,56974,38847,58778,59828,38658,2284066855,69905794,2217120749,70182009,2217109497,270534719,70712750,271610383,71194375,272132193,72248102,273728727,1280608747,272665194,272933065,72010782,1614811782,274254438,1885232662,2153811464,275017613,275282154,2020351693,275813831,477393071,275001804,1751125294,1350070559,271581583,1682146651,276621925,1820082810,1811987787}
local Ol={32142,33477,42060,33852,11164,19334,29592,9432,7695,15367,51821,18581,26274,26852,44874,13330,40269,49833,43182,46380,59454,50209,39798,55340,1946,14685,13050,17329,57584,27523,12006,26460,50817,15708,45784,26941,63026,33947,29630,65024,35917,44014,57069,38871,58875,59846,38658,6183,44930,38887,57977,28658,6719,63406,26639,23303,30305,28454,54487,41451,44138,35529,51230,3718,53862,20502,41216,32653,22762,11479,35271,18099,3020,3887,23815,15759,25252,62053,16506,48459,56581,60531,4508,58642,59003,2127,6,56119,65092,30964,61834,29990,40655,28983,3092,29195,8438,44107,316,13380,38650,62224,30634,42375}
local function Il(ll,Ol)
local Ql={}
for Wl=1,#ll do Ql[Wl]=math.floor(ll[Wl]~Ol[(((Wl-1)%#Ol)+1)]) end
local function Sl(off)
local ct={} local nc2=Ql[off] off=off+1 local ni2=Ql[off] off=off+1 local ns2=Ql[off] off=off+1
for i=1,nc2 do local t=Ql[off] off=off+1
if t==0 then ct[i]=Ql[off] off=off+1
elseif t==1 then local s='' while true do local v=Ql[off] off=off+1 if v==0 then break end s=s..string.char(v) end ct[i]=s
elseif t==2 then ct[i]=(Ql[off]==1) off=off+1
else off=off+1 end end
local ix={}
for i=1,ni2 do ix[i]=Ql[off] off=off+1 end
local sb={}
for i=1,ns2 do local sl=Ql[off] off=off+1 sb[i]=Sl(off) off=sb[i].off end
return {ct=ct,ix=ix,sb=sb,off=off}
end
local function El(Pl,parentR)
local Dl={}
for i=0,255 do Dl[i]=nil end
Dl[1]=true Dl[2]=false
if parentR then for i=0,255 do Dl[i]=parentR[i] end end
local Gl=Pl.ct
local Bl=Pl.ix
Cl=1
while Cl<=#Bl do
local w=Bl[Cl]
Hl=math.floor(w/67108864)%64
Kl=math.floor(w/262144)%256
Rl=math.floor(w/512)%512
Fl=w%512
Tl=Rl>=256 and Gl[Rl-256] or Dl[Rl]
Yl=Fl>=256 and Gl[Fl-256] or Dl[Fl]
if Hl==0 then Cl=Cl+1
elseif Hl==1 then Dl[Kl]=Tl Cl=Cl+1
elseif Hl==2 then Dl[Kl]=nil Cl=Cl+1
elseif Hl==3 then Dl[Kl]=(Rl==1) Cl=Cl+1
elseif Hl==4 then Dl[Kl]=Dl[Rl] Cl=Cl+1
elseif Hl==5 then Dl[Kl]=-Dl[Rl] Cl=Cl+1
elseif Hl==6 then Dl[Kl]=Dl[Rl]+Yl Cl=Cl+1
elseif Hl==7 then Dl[Kl]=Dl[Rl]-Yl Cl=Cl+1
elseif Hl==8 then Dl[Kl]=Dl[Rl]*Yl Cl=Cl+1
elseif Hl==9 then Dl[Kl]=Dl[Rl]/Yl Cl=Cl+1
elseif Hl==10 then Dl[Kl]=Dl[Rl]%Yl Cl=Cl+1
elseif Hl==11 then Dl[Kl]=Dl[Rl]^Yl Cl=Cl+1
elseif Hl==12 then Dl[Kl]=(Dl[Rl]==Yl) Cl=Cl+1
elseif Hl==13 then Dl[Kl]=(Dl[Rl]<Yl) Cl=Cl+1
elseif Hl==14 then Dl[Kl]=(Dl[Rl]<=Yl) Cl=Cl+1
elseif Hl==15 then Dl[Kl]=(Dl[Rl]~=Yl) Cl=Cl+1
elseif Hl==16 then Dl[Kl]=(not Dl[Rl]) Cl=Cl+1
elseif Hl==17 then Dl[Kl]=Dl[Rl] and Yl Cl=Cl+1
elseif Hl==18 then Dl[Kl]=Dl[Rl] or Yl Cl=Cl+1
elseif Hl==19 then Dl[Kl]=#Dl[Rl] Cl=Cl+1
elseif Hl==20 then Dl[Kl]=tostring(Dl[Rl])..tostring(Yl) Cl=Cl+1
elseif Hl==21 then Ul=Rl+Fl*512 if Ul>=131072 then Ul=Ul-262144 end Cl=Cl+1+Ul
elseif Hl==22 then Ul=Rl+Fl*512 if Ul>=131072 then Ul=Ul-262144 end if not Dl[Kl] then Cl=Cl+1+Ul else Cl=Cl+1 end
elseif Hl==23 then Ul=Rl+Fl*512 if Ul>=131072 then Ul=Ul-262144 end if Dl[Kl] then Cl=Cl+1+Ul else Cl=Cl+1 end
elseif Hl==24 then Ul=Rl+Fl*512 if Ul>=131072 then Ul=Ul-262144 end if(Dl[Kl]-Dl[Kl+2])>Dl[Kl+1] then Cl=Cl+1+Ul else Cl=Cl+1 end
elseif Hl==25 then Ul=Rl+Fl*512 if Ul>=131072 then Ul=Ul-262144 end Dl[Kl]=Dl[Kl]+Dl[Kl+2] if(Dl[Kl+2]>0 and Dl[Kl]<=Dl[Kl+1]) or(Dl[Kl+2]<=0 and Dl[Kl]>=Dl[Kl+1]) then Cl=Cl+Ul else Cl=Cl+1 end
elseif Hl==26 then local ag={} for ai=1,Rl do ag[ai]=Dl[Kl+ai] end local rt=Dl[Kl](table.unpack(ag)) Dl[Kl]=rt Cl=Cl+1
elseif Hl==27 then return Dl[Kl]
elseif Hl==28 then Dl[Kl]=_G[Tl] Cl=Cl+1
elseif Hl==29 then _G[Tl]=Dl[Kl] Cl=Cl+1
elseif Hl==30 then Dl[Kl]=Dl[Rl][Yl] Cl=Cl+1
elseif Hl==31 then Dl[Kl][Tl]=Yl Cl=Cl+1
elseif Hl==32 then Dl[Kl]=Dl[Rl][Yl] Cl=Cl+1
elseif Hl==33 then Dl[Kl][Tl]=Dl[Fl] Cl=Cl+1
elseif Hl==34 then Dl[Kl]={} Cl=Cl+1
elseif Hl==35 then Cl=Cl+1
elseif Hl==36 then local sp=Pl.sb[Tl] local cr={} for ci=0,255 do cr[ci]=Dl[ci] end Dl[Kl]=function(...) local nr={} for ni=0,255 do nr[ni]=cr[ni] end local ca={...} for ai=1,#ca do nr[7+ai]=ca[ai] end return El(sp,nr) end Cl=Cl+1
elseif Hl==37 then Dl[Kl]=type(Dl[Rl]) Cl=Cl+1
elseif Hl==38 then Ul=Rl+Fl*512 if Ul>=131072 then Ul=Ul-262144 end local ok2,vl=next(Dl[Kl+1],Dl[Kl+3]) if ok2 then Dl[Kl+2]=ok2 Dl[Kl+3]=vl Cl=Cl+Ul else Cl=Cl+1 end
elseif Hl==39 then Dl[Kl]=tonumber(Dl[Rl]) Cl=Cl+1
elseif Hl==40 then Dl[Kl]=tostring(Dl[Rl]) Cl=Cl+1
elseif Hl==41 then Dl[Kl+3]=nil Cl=Cl+1
else Cl=Cl+1 end
end
return nil
end
local mp=Sl(1)
El(mp)
end
Il(ll,Ol)
