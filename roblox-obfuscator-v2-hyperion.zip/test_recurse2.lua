local function count(n)
    if n <= 0 then return 42 end
    return 1000 + count(n - 1)
end
print(count(1))
