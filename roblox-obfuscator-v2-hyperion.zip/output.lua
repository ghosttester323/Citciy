print((function()local _s={180,209,216,216,219,140,210,222,219,217,140,219,206,210,225,223,207,205,224,219,222,141}local _r=""local _o=108 for _i=1,#_s do _r=_r..string.char(_s[_i]-_o)end return _r end)())
local Il = 10
local ll = 25
print((function()local _s={201,220,234,236,227,235,177,151}local _r=""local _o=119 for _i=1,#_s do _r=_r..string.char(_s[_i]-_o)end return _r end)() .. (Il + ll))
