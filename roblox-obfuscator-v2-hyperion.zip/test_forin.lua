local vm = dofile './core/vm.lua'
local t = dofile './core/tokenizer.lua'
local prng = dofile './core/prng.lua'
local reserved = dofile './core/reserved.lua'
local naming = dofile './core/naming.lua'
naming.init(reserved)
local env = {prng=prng, reserved=reserved, naming=naming, tokenizer=t, _baseDir='.'}
prng.setseed(42)

-- Test with simple for-in
local source = "for k,v in pairs({10,20,30}) do print(k,v) end"
print("Source:", source)
local result = vm.process(source, env)
print("Output:", result:sub(1,200))
print("---")
os.exit()

-- Test with local variable table
source = [[local t = {10,20,30} for k,v in pairs(t) do print(k,v) end]]
print("Source2:", source)
result = vm.process(source, env)
print("Output:", result:sub(1,200))
